import httpx
import logging
import sys
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

SAMPLE_REPORTS = [
    {
        "name": "Federal_Reserve_Annual_Report_2023.pdf",
        "url": "https://www.federalreserve.gov/publications/files/2023-annual-report.pdf",
        "description": "Federal Reserve 2023 Annual Report"
    },
    {
        "name": "Federal_Reserve_Monetary_Policy_Report_July_2024.pdf",
        "url": "https://www.federalreserve.gov/monetarypolicy/files/20240709_mprfullreport.pdf",
        "description": "Federal Reserve Monetary Policy Report, July 2024"
    },
    {
        "name": "IMF_Annual_Report_2023.pdf",
        "url": "https://www.imf.org/-/media/Files/Publications/AR/2023/English/text.ashx",
        "description": "IMF Annual Report 2023"
    },
    {
        "name": "World_Bank_Annual_Report_2023.pdf",
        "url": "https://documents1.worldbank.org/curated/en/099081523163013220/pdf/BOSIB0cc20e5e003009d70088cb39d2c943.pdf",
        "description": "World Bank Annual Report 2023"
    },
    {
        "name": "Apple_10K_2023.pdf",
        "url": "https://s2.q4cdn.com/470004039/files/doc_earnings/2023/q4/filing/_10-K-Q4-2023-As-Filed.pdf",
        "description": "Apple Inc. 2023 Form 10-K"
    },
    {
        "name": "Microsoft_Annual_Report_2023.pdf",
        "url": "https://c.s-microsoft.com/en-us/CMSFiles/2023_Annual_Report.pdf?version=1fd2d034-733f-42e7-a9a3-5c029b9f7127",
        "description": "Microsoft 2023 Annual Report"
    }
]

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
}

def main():
    script_dir = Path(__file__).resolve().parent
    project_root = script_dir.parent
    raw_uploads_dir = project_root / "data" / "raw_uploads"
    
    raw_uploads_dir.mkdir(parents=True, exist_ok=True)
    
    logger.info(f"Downloading sample PDFs to: {raw_uploads_dir}")
    
    successful_downloads = 0
    total_files = len(SAMPLE_REPORTS)
    
    with httpx.Client(timeout=60.0, follow_redirects=True, headers=HEADERS) as client:
        for report in SAMPLE_REPORTS:
            file_path = raw_uploads_dir / report["name"]
            
            if file_path.exists():
                logger.info(f"Skipping {report['name']} - already exists.")
                successful_downloads += 1
                continue
                
            logger.info(f"Downloading {report['name']} from {report['url']}...")
            try:
                response = client.get(report["url"])
                response.raise_for_status()
                
                with open(file_path, "wb") as f:
                    f.write(response.content)
                    
                logger.info(f"Successfully downloaded {report['name']}.")
                successful_downloads += 1
            except Exception as e:
                logger.warning(f"Failed to download {report['name']}: {e}")
                
    logger.info(f"Download complete: {successful_downloads} of {total_files} files downloaded successfully.")

if __name__ == "__main__":
    main()
