"""Tests for PDF processing and metadata generation."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from src.ingestion.pdf_processor import PDFProcessor, DocumentMetadata


def test_process_pdf(sample_pdf, temp_dir, monkeypatch):
    """Process a sample PDF and verify metadata and rendered pages."""
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))

    # Reset settings singleton
    import src.config
    src.config._settings = None

    processor = PDFProcessor()
    metadata = processor.process_pdf(sample_pdf)

    assert isinstance(metadata, DocumentMetadata)
    assert metadata.document_id is not None
    assert metadata.document_name == sample_pdf.name
    assert metadata.total_pages == 3

    # Check page images exist
    for img_path in metadata.page_image_paths:
        p = Path(img_path) if not isinstance(img_path, Path) else img_path
        assert p.exists(), f"Page image not found: {p}"


def test_process_pdf_invalid_file(temp_dir, monkeypatch):
    """Processing a non-PDF file should raise an exception."""
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))

    import src.config
    src.config._settings = None

    processor = PDFProcessor()
    invalid_file = temp_dir / "invalid.pdf"
    invalid_file.write_bytes(b"\x00\x01\x02\x03\x04not a valid pdf file")

    with pytest.raises(ValueError):
        processor.process_pdf(invalid_file)


def test_load_metadata(sample_pdf, temp_dir, monkeypatch):
    """Process then load metadata, verify round-trip."""
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))

    import src.config
    src.config._settings = None

    processor = PDFProcessor()
    metadata = processor.process_pdf(sample_pdf)

    loaded = processor.load_metadata(metadata.document_id)
    assert loaded is not None
    assert loaded.document_id == metadata.document_id
    assert loaded.document_name == metadata.document_name
    assert loaded.total_pages == metadata.total_pages


def test_list_documents(sample_pdf, temp_dir, monkeypatch):
    """Process a PDF and verify it appears in list_documents."""
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))

    import src.config
    src.config._settings = None

    processor = PDFProcessor()
    metadata = processor.process_pdf(sample_pdf)

    docs = processor.list_documents()
    assert len(docs) >= 1
    assert any(d.document_id == metadata.document_id for d in docs)


def test_delete_document(sample_pdf, temp_dir, monkeypatch):
    """Process then delete, verify files removed."""
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))

    import src.config
    src.config._settings = None

    processor = PDFProcessor()
    metadata = processor.process_pdf(sample_pdf)

    processor.delete_document(metadata.document_id)
    with pytest.raises(FileNotFoundError):
        processor.load_metadata(metadata.document_id)
