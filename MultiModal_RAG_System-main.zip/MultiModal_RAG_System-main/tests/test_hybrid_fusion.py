"""Tests for hybrid retrieval with RRF fusion."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from unittest.mock import MagicMock


def test_rrf_fusion(temp_dir, monkeypatch):
    """Verify RRF fusion produces sorted results from both pipelines."""
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.bm25_indexer import BM25Index, BM25Result
    from src.retrieval.hybrid_fusion import HybridRetriever, FusedResult

    # Create real BM25 and mock Qdrant
    bm25 = MagicMock(spec=BM25Index)
    qdrant = MagicMock()

    bm25.search.return_value = [
        BM25Result(doc_id="doc1", page_number=1, score=0.9, extracted_text="revenue report"),
        BM25Result(doc_id="doc2", page_number=2, score=0.7, extracted_text="balance sheet"),
    ]
    qdrant.search.return_value = [
        {"document_id": "doc2", "document_name": "report.pdf", "page_number": 2, "score": 0.95, "image_path": "", "extracted_text": "balance sheet"},
        {"document_id": "doc3", "document_name": "report2.pdf", "page_number": 1, "score": 0.85, "image_path": "", "extracted_text": "cash flow"},
    ]

    retriever = HybridRetriever(bm25, qdrant)
    results = retriever.retrieve(
        query="test query",
        query_embedding=[[0.1] * 128],  # dummy embedding
        top_k=5,
    )

    assert len(results) >= 1
    # Results should be sorted by fused_score descending
    scores = [r.fused_score for r in results]
    assert scores == sorted(scores, reverse=True)


def test_bm25_only_retrieval(temp_dir, monkeypatch):
    """BM25-only mode: visual_score should be 0."""
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.bm25_indexer import BM25Index, BM25Result
    from src.retrieval.hybrid_fusion import HybridRetriever

    bm25 = MagicMock(spec=BM25Index)
    qdrant = MagicMock()

    bm25.search.return_value = [
        BM25Result(doc_id="doc1", page_number=1, score=0.9, extracted_text="revenue"),
    ]

    retriever = HybridRetriever(bm25, qdrant)
    results = retriever.retrieve_bm25_only(query="revenue", top_k=5)

    assert len(results) == 1
    assert results[0].visual_score == 0.0
    assert results[0].lexical_score > 0.0


def test_deduplication(temp_dir, monkeypatch):
    """Same page from both pipelines should appear only once."""
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.bm25_indexer import BM25Index, BM25Result
    from src.retrieval.hybrid_fusion import HybridRetriever

    bm25 = MagicMock(spec=BM25Index)
    qdrant = MagicMock()

    bm25.search.return_value = [
        BM25Result(doc_id="doc1", page_number=1, score=0.9, extracted_text="revenue"),
    ]
    qdrant.search.return_value = [
        {"document_id": "doc1", "document_name": "r.pdf", "page_number": 1, "score": 0.95, "image_path": "", "extracted_text": "revenue"},
    ]

    retriever = HybridRetriever(bm25, qdrant)
    results = retriever.retrieve(
        query="revenue",
        query_embedding=[[0.1] * 128],
        top_k=5,
    )

    # Should be deduplicated to 1
    assert len(results) == 1
    assert results[0].document_id == "doc1"


def test_empty_results(temp_dir, monkeypatch):
    """Both pipelines returning empty should produce empty results."""
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.bm25_indexer import BM25Index
    from src.retrieval.hybrid_fusion import HybridRetriever

    bm25 = MagicMock(spec=BM25Index)
    qdrant = MagicMock()

    bm25.search.return_value = []
    qdrant.search.return_value = []

    retriever = HybridRetriever(bm25, qdrant)
    results = retriever.retrieve(
        query="nonexistent",
        query_embedding=[[0.1] * 128],
        top_k=5,
    )

    assert len(results) == 0
