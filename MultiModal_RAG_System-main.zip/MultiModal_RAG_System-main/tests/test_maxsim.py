"""Tests for MaxSim late interaction scoring."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
import torch
import numpy as np
from PIL import Image
from src.retrieval.late_interaction import MaxSimScorer


def test_maxsim_identical_vectors():
    """Identical query and doc vectors should produce a high positive score."""
    q = torch.rand(10, 128)  # [num_query_tokens, embed_dim]
    d = q.clone()

    score = MaxSimScorer.score(q, d)
    assert score > 0


def test_maxsim_orthogonal_vectors():
    """Orthogonal vectors should produce a score near zero."""
    q = torch.zeros(10, 128)
    q[:, 0] = 1.0  # All query tokens point along dim 0

    d = torch.zeros(15, 128)
    d[:, 1] = 1.0  # All doc patches point along dim 1

    score = MaxSimScorer.score(q, d)
    assert abs(score) < 1e-5


def test_maxsim_batch_scoring():
    """Score a query against multiple pages, verify list length."""
    q = torch.rand(10, 128)
    pages = [torch.rand(15, 128), torch.rand(20, 128), torch.rand(12, 128)]

    scores = MaxSimScorer.score_batch(q, pages)
    assert len(scores) == 3
    assert all(isinstance(s, float) for s in scores)


def test_patch_relevance_shape():
    """Compute patch relevance and verify output shape."""
    q = torch.rand(5, 128)
    d = torch.rand(256, 128)  # 16x16 patch grid

    rel = MaxSimScorer.compute_patch_relevance(
        q, d, image_width=512, image_height=512, patch_grid=(16, 16)
    )
    assert rel.shape == (16, 16)


def test_patch_relevance_normalization():
    """Patch relevance values should be normalized to [0, 1]."""
    q = torch.rand(5, 128)
    d = torch.rand(256, 128)

    rel = MaxSimScorer.compute_patch_relevance(
        q, d, image_width=512, image_height=512, patch_grid=(16, 16)
    )
    assert rel.min() >= -1e-6
    assert rel.max() <= 1.0 + 1e-6


def test_heatmap_overlay(temp_dir):
    """Generate heatmap overlay on a synthetic image."""
    # Create a test image
    img = Image.new("RGB", (512, 512), color="white")
    img_path = temp_dir / "test_page.png"
    img.save(str(img_path))

    # Create synthetic relevance map
    relevance = np.random.rand(16, 16).astype(np.float64)
    # Normalize
    relevance = (relevance - relevance.min()) / (relevance.max() - relevance.min())

    output_path = temp_dir / "heatmap_overlay.png"
    result = MaxSimScorer.generate_heatmap_overlay(
        str(img_path), relevance, output_path=str(output_path)
    )
    assert isinstance(result, Image.Image)
    assert result.size == (512, 512)
    assert output_path.exists()
