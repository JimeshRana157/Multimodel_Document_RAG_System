"""Tests for FastAPI endpoints."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


def test_health_endpoint(temp_dir, monkeypatch):
    """GET /health should return 200 with expected fields."""
    monkeypatch.setenv("QDRANT_URL", "")
    monkeypatch.setenv("QDRANT_LOCAL_PATH", str(temp_dir / "qdrant"))
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)
    (temp_dir / "renders").mkdir(exist_ok=True)
    (temp_dir / "uploads").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    # Reset lazy singletons in routes
    import api.routes as routes
    routes._colpali_embedder = None
    routes._qdrant_store = None
    routes._bm25_index = None
    routes._vision_llm = None

    from fastapi.testclient import TestClient
    from api.main import app

    client = TestClient(app)
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert "status" in data
    assert "qdrant_connected" in data
    assert "indexed_documents" in data
    assert "indexed_pages" in data


def test_documents_list_empty(temp_dir, monkeypatch):
    """GET /documents on empty system should return a list."""
    monkeypatch.setenv("QDRANT_URL", "")
    monkeypatch.setenv("QDRANT_LOCAL_PATH", str(temp_dir / "qdrant"))
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)
    (temp_dir / "renders").mkdir(exist_ok=True)
    (temp_dir / "uploads").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    import api.routes as routes
    routes._colpali_embedder = None
    routes._qdrant_store = None
    routes._bm25_index = None
    routes._vision_llm = None

    from fastapi.testclient import TestClient
    from api.main import app

    client = TestClient(app)
    response = client.get("/documents")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
