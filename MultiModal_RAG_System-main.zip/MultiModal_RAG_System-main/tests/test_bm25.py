"""Tests for BM25 lexical index."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from src.ingestion.text_extractor import PageText


def test_add_and_search(temp_dir, monkeypatch):
    """Add documents and search for matching terms."""
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.bm25_indexer import BM25Index, BM25Result

    index = BM25Index()
    pages = [
        PageText(page_number=1, raw_text="Total revenue was fifty million dollars in fiscal year 2024.", tables=[]),
        PageText(page_number=2, raw_text="Net loss this quarter was ten million.", tables=[]),
        PageText(page_number=3, raw_text="Some other unrelated text here.", tables=[]),
        PageText(page_number=4, raw_text="And another page without the word.", tables=[]),
    ]
    index.add_document("doc1", pages)

    results = index.search("revenue", top_k=5)
    assert len(results) > 0
    assert isinstance(results[0], BM25Result)
    assert results[0].doc_id == "doc1"
    assert results[0].score > 0


def test_empty_search(temp_dir, monkeypatch):
    """Search on empty index returns empty."""
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.bm25_indexer import BM25Index

    index = BM25Index()
    results = index.search("revenue", top_k=5)
    assert len(results) == 0


def test_remove_document(temp_dir, monkeypatch):
    """Add then remove a document, search should not find it."""
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.bm25_indexer import BM25Index

    index = BM25Index()
    pages = [
        PageText(page_number=1, raw_text="Revenue growth was strong.", tables=[]),
        PageText(page_number=2, raw_text="Unrelated page.", tables=[]),
        PageText(page_number=3, raw_text="Another unrelated.", tables=[])
    ]
    index.add_document("doc_remove", pages)

    assert len(index.search("revenue")) > 0
    index.remove_document("doc_remove")
    assert len(index.search("revenue")) == 0


def test_persistence(temp_dir, monkeypatch):
    """Add documents, create new index from same path, verify search works."""
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.bm25_indexer import BM25Index

    index = BM25Index()
    pages = [
        PageText(page_number=1, raw_text="Persistent financial report about dividends.", tables=[]),
        PageText(page_number=2, raw_text="Unrelated page.", tables=[]),
        PageText(page_number=3, raw_text="Another unrelated.", tables=[])
    ]
    index.add_document("doc_persist", pages)

    # Create new index instance (should load from disk)
    src.config._settings = None
    index2 = BM25Index()
    results = index2.search("dividends")
    assert len(results) > 0
    assert results[0].doc_id == "doc_persist"
