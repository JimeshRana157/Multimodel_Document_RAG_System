"""Tests for Qdrant vector store."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
import random


def test_health_check(temp_dir, monkeypatch):
    """Create QdrantStore with local path, verify health."""
    monkeypatch.setenv("QDRANT_URL", "")
    monkeypatch.setenv("QDRANT_LOCAL_PATH", str(temp_dir / "qdrant_test"))
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.qdrant_store import QdrantStore
    store = QdrantStore()
    assert store.health_check() is True


def test_ensure_collection(temp_dir, monkeypatch):
    """Create collection with embed_dim=128."""
    monkeypatch.setenv("QDRANT_URL", "")
    monkeypatch.setenv("QDRANT_LOCAL_PATH", str(temp_dir / "qdrant_test"))
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.qdrant_store import QdrantStore
    store = QdrantStore()
    store.ensure_collection(embed_dim=128)
    info = store.get_collection_info()
    assert info["points_count"] == 0


def test_upsert_and_search(temp_dir, monkeypatch):
    """Upsert synthetic multivector data, search, verify results."""
    monkeypatch.setenv("QDRANT_URL", "")
    monkeypatch.setenv("QDRANT_LOCAL_PATH", str(temp_dir / "qdrant_test"))
    monkeypatch.setenv("QDRANT_COLLECTION", "test_upsert")
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.qdrant_store import QdrantStore
    store = QdrantStore()
    store.ensure_collection(embed_dim=128)

    # Create synthetic multivector (10 patches, 128 dims each)
    page_embedding = [[random.random() for _ in range(128)] for _ in range(10)]
    metadata = {
        "document_id": "test_doc_1",
        "document_name": "test.pdf",
        "page_number": 1,
        "image_path": "/test/page.png",
        "extracted_text": "sample text",
        "total_pages": 5,
    }

    count = store.upsert_pages([page_embedding], [metadata])
    assert count == 1

    # Search with a query multivector
    query_embedding = [[random.random() for _ in range(128)] for _ in range(5)]
    results = store.search(query_embedding, top_k=5)
    assert len(results) >= 1
    assert results[0]["document_id"] == "test_doc_1"


def test_delete_document(temp_dir, monkeypatch):
    """Upsert then delete, verify count is 0."""
    monkeypatch.setenv("QDRANT_URL", "")
    monkeypatch.setenv("QDRANT_LOCAL_PATH", str(temp_dir / "qdrant_test"))
    monkeypatch.setenv("QDRANT_COLLECTION", "test_delete")
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.qdrant_store import QdrantStore
    store = QdrantStore()
    store.ensure_collection(embed_dim=128)

    page_embedding = [[random.random() for _ in range(128)] for _ in range(10)]
    metadata = {
        "document_id": "del_doc",
        "document_name": "delete_me.pdf",
        "page_number": 1,
        "image_path": "",
        "extracted_text": "",
        "total_pages": 1,
    }
    store.upsert_pages([page_embedding], [metadata])
    assert store.count_points() == 1

    store.delete_document("del_doc")
    assert store.count_points() == 0


def test_get_all_documents(temp_dir, monkeypatch):
    """Upsert from 2 different doc_ids, verify get_all_documents returns 2."""
    monkeypatch.setenv("QDRANT_URL", "")
    monkeypatch.setenv("QDRANT_LOCAL_PATH", str(temp_dir / "qdrant_test"))
    monkeypatch.setenv("QDRANT_COLLECTION", "test_multi_doc")
    monkeypatch.setenv("INDEX_DIR", str(temp_dir / "index"))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(temp_dir / "renders"))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(temp_dir / "uploads"))
    (temp_dir / "index").mkdir(exist_ok=True)

    import src.config
    src.config._settings = None

    from src.indexing.qdrant_store import QdrantStore
    store = QdrantStore()
    store.ensure_collection(embed_dim=128)

    for doc_id in ["multi_doc_1", "multi_doc_2"]:
        emb = [[random.random() for _ in range(128)] for _ in range(10)]
        meta = {
            "document_id": doc_id,
            "document_name": f"{doc_id}.pdf",
            "page_number": 1,
            "image_path": "",
            "extracted_text": "",
            "total_pages": 1,
        }
        store.upsert_pages([emb], [meta])

    docs = store.get_all_documents()
    assert len(docs) == 2
