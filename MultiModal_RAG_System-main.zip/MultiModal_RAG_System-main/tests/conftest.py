import sys
from pathlib import Path

# Ensure project root is on sys.path for 'from src...' imports
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

import pytest
import fitz  # PyMuPDF
import tempfile
import shutil
import json
import os

@pytest.fixture(scope="session")
def test_data_dir():
    """Creates a temporary directory for test data that lasts for the whole session."""
    temp_dir = tempfile.mkdtemp(prefix="financial_rag_test_data_")
    dir_path = Path(temp_dir)
    yield dir_path
    shutil.rmtree(temp_dir, ignore_errors=True)

@pytest.fixture(scope="session")
def sample_pdf(test_data_dir: Path) -> Path:
    """Creates a small 3-page test PDF for general testing."""
    pdf_path = test_data_dir / "sample_financial_report.pdf"
    
    doc = fitz.open()  # new empty document
    
    # Page 1
    page1 = doc.new_page()
    page1.insert_text(fitz.Point(72, 72), "Financial Report 2024", fontsize=24)
    page1.insert_text(fitz.Point(72, 120), "Revenue was $50 million. Net income increased by 15%.", fontsize=12)
    # Simple mock table representation
    page1.insert_text(fitz.Point(72, 160), "Category | Value", fontsize=12)
    page1.insert_text(fitz.Point(72, 180), "-------- | -----", fontsize=12)
    page1.insert_text(fitz.Point(72, 200), "Sales    | 40M", fontsize=12)
    page1.insert_text(fitz.Point(72, 220), "Services | 10M", fontsize=12)

    # Page 2
    page2 = doc.new_page()
    page2.insert_text(fitz.Point(72, 72), "Balance Sheet", fontsize=24)
    page2.insert_text(fitz.Point(72, 120), "Total assets were $100M.", fontsize=12)
    page2.insert_text(fitz.Point(72, 140), "Total liabilities were $60M.", fontsize=12)
    page2.insert_text(fitz.Point(72, 160), "Total equity was $40M.", fontsize=12)
    
    # Page 3
    page3 = doc.new_page()
    page3.insert_text(fitz.Point(72, 72), "Cash Flow Statement", fontsize=24)
    page3.insert_text(fitz.Point(72, 120), "Operating cash flow for the period was $25M.", fontsize=12)
    
    doc.save(pdf_path)
    doc.close()
    
    return pdf_path

@pytest.fixture(scope="session")
def sample_pdf_2(test_data_dir: Path) -> Path:
    """Creates a second test PDF with different content for testing multi-document scenarios."""
    pdf_path = test_data_dir / "market_analysis_q4.pdf"
    
    doc = fitz.open()
    
    # Page 1
    page1 = doc.new_page()
    page1.insert_text(fitz.Point(72, 72), "Market Analysis Q4", fontsize=24)
    page1.insert_text(fitz.Point(72, 120), "Our market share increased to 22% in the last quarter.", fontsize=12)
    
    # Page 2
    page2 = doc.new_page()
    page2.insert_text(fitz.Point(72, 72), "Growth Projections", fontsize=24)
    page2.insert_text(fitz.Point(72, 120), "Expected growth rate for next year is 8.5%.", fontsize=12)
    
    doc.save(pdf_path)
    doc.close()
    
    return pdf_path

@pytest.fixture
def temp_dir():
    """Creates a fresh temp directory per test."""
    temp_dir = tempfile.mkdtemp(prefix="financial_rag_test_env_")
    dir_path = Path(temp_dir)
    yield dir_path
    shutil.rmtree(temp_dir, ignore_errors=True)

@pytest.fixture
def mock_env_vars(monkeypatch, temp_dir: Path):
    """Sets environment variables for testing, isolating from real data."""
    qdrant_path = temp_dir / "qdrant"
    index_path = temp_dir / "index"
    renders_path = temp_dir / "renders"
    uploads_path = temp_dir / "uploads"
    
    qdrant_path.mkdir()
    index_path.mkdir()
    renders_path.mkdir()
    uploads_path.mkdir()
    
    monkeypatch.setenv("QDRANT_LOCAL_PATH", str(qdrant_path))
    monkeypatch.setenv("INDEX_DIR", str(index_path))
    monkeypatch.setenv("PAGE_RENDERS_DIR", str(renders_path))
    monkeypatch.setenv("RAW_UPLOADS_DIR", str(uploads_path))
    
    return {
        "QDRANT_LOCAL_PATH": qdrant_path,
        "INDEX_DIR": index_path,
        "PAGE_RENDERS_DIR": renders_path,
        "RAW_UPLOADS_DIR": uploads_path
    }
