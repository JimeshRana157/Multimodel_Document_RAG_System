"""Tests for ColPali embedder."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


def test_colpali_import():
    """Test that embedder can be imported and initialized."""
    from src.indexing.colpali_engine import ColPaliEmbedder
    embedder = ColPaliEmbedder()
    assert embedder.embedding_dim == 128


def test_embedding_shape():
    """Embed a small image, check output shape is [1, N, D]."""
    from src.indexing.colpali_engine import ColPaliEmbedder
    from PIL import Image

    embedder = ColPaliEmbedder()
    img = Image.new("RGB", (224, 224), color="white")
    output = embedder.embed_pages([img], batch_size=1)

    assert output.dim() == 3  # [1, num_patches, embed_dim]
    assert output.shape[0] == 1
    assert output.shape[1] > 0  # num_patches > 0
    assert output.shape[2] == 128  # embed_dim == 128


def test_query_embedding_shape():
    """Embed a query string, check shape [1, M, D]."""
    from src.indexing.colpali_engine import ColPaliEmbedder

    embedder = ColPaliEmbedder()
    output = embedder.embed_query("What is the total revenue?")

    assert output.dim() == 3  # [1, num_query_tokens, embed_dim]
    assert output.shape[0] == 1
    assert output.shape[1] > 0
    assert output.shape[2] == 128
