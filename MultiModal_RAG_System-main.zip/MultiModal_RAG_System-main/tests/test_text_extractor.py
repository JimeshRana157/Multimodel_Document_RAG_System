"""Tests for text extraction."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from src.ingestion.text_extractor import TextExtractor, PageText


def test_extract_text(sample_pdf):
    """Extract text from sample PDF and verify structure."""
    extractor = TextExtractor()
    pages = extractor.extract_text(sample_pdf)

    assert isinstance(pages, list)
    assert len(pages) == 3  # 3-page fixture
    for page in pages:
        assert isinstance(page, PageText)
        assert isinstance(page.page_number, int)
        assert isinstance(page.raw_text, str)


def test_extract_text_content(sample_pdf):
    """Verify extracted text contains expected financial terms."""
    extractor = TextExtractor()
    pages = extractor.extract_text(sample_pdf)

    all_text = " ".join(p.raw_text for p in pages)
    assert "Financial Report" in all_text or "Revenue" in all_text or "revenue" in all_text.lower()


def test_page_count_matches(sample_pdf):
    """Number of PageText items matches expected page count."""
    extractor = TextExtractor()
    pages = extractor.extract_text(sample_pdf)
    assert len(pages) == 3


def test_extract_nonexistent_file():
    """Extracting from nonexistent file should raise FileNotFoundError."""
    extractor = TextExtractor()
    with pytest.raises(FileNotFoundError):
        extractor.extract_text(Path("/nonexistent/file.pdf"))
