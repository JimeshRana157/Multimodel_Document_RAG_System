"""
Hybrid Retrieval with Reciprocal Rank Fusion (RRF)

Combines BM25 lexical retrieval and ColPali visual retrieval
using configurable RRF fusion:

    RRF(d) = Σ_{r ∈ R}  1 / (k + rank_r(d))

Supports configurable visual vs. lexical weighting.
"""

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from src.config import get_settings
from src.indexing.bm25_indexer import BM25Index
from src.indexing.qdrant_store import QdrantStore
from src.retrieval.late_interaction import MaxSimScorer

logger = logging.getLogger(__name__)


@dataclass
class FusedResult:
    """A single fused retrieval result."""

    document_id: str
    document_name: str
    page_number: int
    visual_score: float
    lexical_score: float
    fused_score: float
    image_path: str
    extracted_text: str
    relevance_map_path: Optional[str] = None


class HybridRetriever:
    """
    Hybrid retriever combining BM25 lexical and ColPali visual retrieval
    with Reciprocal Rank Fusion.
    """

    def __init__(
        self,
        bm25_index: BM25Index,
        qdrant_store: QdrantStore,
    ):
        self.bm25 = bm25_index
        self.qdrant = qdrant_store
        self.settings = get_settings()
        logger.info("HybridRetriever initialized")

    def retrieve(
        self,
        query: str,
        query_embedding: Optional[list[list[float]]] = None,
        top_k: Optional[int] = None,
        visual_weight: Optional[float] = None,
        lexical_weight: Optional[float] = None,
        rrf_k: Optional[int] = None,
        doc_filter: Optional[str] = None,
    ) -> list[FusedResult]:
        """
        Run hybrid retrieval combining BM25 and visual search with RRF.

        Args:
            query: Natural language query string.
            query_embedding: Pre-computed ColPali query multi-vector.
                If None, only BM25 retrieval is performed.
            top_k: Number of results to return (default from settings).
            visual_weight: Weight for visual RRF scores (default from settings).
            lexical_weight: Weight for lexical RRF scores (default from settings).
            rrf_k: RRF constant k (default from settings).
            doc_filter: Optional document_id to filter results.

        Returns:
            List of FusedResult, sorted by fused_score descending.
        """
        top_k = top_k or self.settings.top_k
        visual_weight = visual_weight if visual_weight is not None else self.settings.visual_weight
        lexical_weight = lexical_weight if lexical_weight is not None else self.settings.lexical_weight
        rrf_k = rrf_k or self.settings.rrf_k

        # Fetch more candidates than top_k for better fusion
        fetch_k = max(top_k * 4, 20)

        # --- BM25 Retrieval ---
        bm25_results = []
        try:
            bm25_results = self.bm25.search(query, top_k=fetch_k)
            logger.info("BM25 returned %d results for query: %s", len(bm25_results), query[:80])
        except Exception as e:
            logger.warning("BM25 retrieval failed: %s", e)

        # --- Visual Retrieval ---
        visual_results = []
        if query_embedding is not None:
            try:
                visual_results = self.qdrant.search(
                    query_embedding=query_embedding,
                    top_k=fetch_k,
                    doc_filter=doc_filter,
                )
                logger.info(
                    "Visual search returned %d results for query: %s",
                    len(visual_results),
                    query[:80],
                )
            except Exception as e:
                logger.warning("Visual retrieval failed: %s", e)

        # --- Handle edge cases ---
        if not bm25_results and not visual_results:
            logger.warning("Both retrieval pipelines returned empty results")
            return []

        # --- Build RRF rankings ---
        # Key: (doc_id, page_num) -> metadata
        page_metadata: dict[tuple[str, int], dict] = {}

        # BM25 ranked list
        bm25_ranked: list[tuple[str, int]] = []
        for r in bm25_results:
            key = (r.doc_id, r.page_number)
            bm25_ranked.append(key)
            if key not in page_metadata:
                page_metadata[key] = {
                    "document_id": r.doc_id,
                    "document_name": "",  # BM25 doesn't have this
                    "page_number": r.page_number,
                    "image_path": "",
                    "extracted_text": r.extracted_text,
                    "bm25_score": r.score,
                }
            else:
                page_metadata[key]["bm25_score"] = r.score
                if r.extracted_text:
                    page_metadata[key]["extracted_text"] = r.extracted_text

        # Visual ranked list
        visual_ranked: list[tuple[str, int]] = []
        for r in visual_results:
            doc_id = r.get("document_id", "")
            page_num = r.get("page_number", 0)
            key = (doc_id, page_num)
            visual_ranked.append(key)
            if key not in page_metadata:
                page_metadata[key] = {
                    "document_id": doc_id,
                    "document_name": r.get("document_name", ""),
                    "page_number": page_num,
                    "image_path": r.get("image_path", ""),
                    "extracted_text": r.get("extracted_text", ""),
                    "visual_score": r.get("score", 0.0),
                }
            else:
                page_metadata[key]["document_name"] = r.get("document_name", "")
                page_metadata[key]["image_path"] = r.get("image_path", "")
                page_metadata[key]["visual_score"] = r.get("score", 0.0)
                if r.get("extracted_text"):
                    page_metadata[key]["extracted_text"] = r.get("extracted_text", "")

        # --- Compute RRF scores ---
        rrf_scores: dict[tuple[str, int], dict[str, float]] = {}

        # RRF from BM25
        for rank, key in enumerate(bm25_ranked, start=1):
            if key not in rrf_scores:
                rrf_scores[key] = {"lexical_rrf": 0.0, "visual_rrf": 0.0}
            rrf_scores[key]["lexical_rrf"] = 1.0 / (rrf_k + rank)

        # RRF from visual
        for rank, key in enumerate(visual_ranked, start=1):
            if key not in rrf_scores:
                rrf_scores[key] = {"lexical_rrf": 0.0, "visual_rrf": 0.0}
            rrf_scores[key]["visual_rrf"] = 1.0 / (rrf_k + rank)

        # --- Fuse with weights ---
        fused_results: list[FusedResult] = []
        for key, scores in rrf_scores.items():
            meta = page_metadata.get(key, {})

            lexical_rrf = scores["lexical_rrf"]
            visual_rrf = scores["visual_rrf"]
            fused = (lexical_weight * lexical_rrf) + (visual_weight * visual_rrf)

            # Apply document filter
            if doc_filter and meta.get("document_id") != doc_filter:
                continue

            fused_results.append(
                FusedResult(
                    document_id=meta.get("document_id", key[0]),
                    document_name=meta.get("document_name", ""),
                    page_number=meta.get("page_number", key[1]),
                    visual_score=meta.get("visual_score", 0.0),
                    lexical_score=meta.get("bm25_score", 0.0),
                    fused_score=fused,
                    image_path=meta.get("image_path", ""),
                    extracted_text=meta.get("extracted_text", ""),
                )
            )

        # Sort by fused score descending
        fused_results.sort(key=lambda x: x.fused_score, reverse=True)

        # Deduplicate (should already be unique by key, but defensive)
        seen = set()
        deduped = []
        for r in fused_results:
            key = (r.document_id, r.page_number)
            if key not in seen:
                seen.add(key)
                deduped.append(r)

        result = deduped[:top_k]
        logger.info(
            "Hybrid retrieval returned %d results (visual_w=%.2f, lexical_w=%.2f, rrf_k=%d)",
            len(result),
            visual_weight,
            lexical_weight,
            rrf_k,
        )
        return result

    def retrieve_bm25_only(
        self, query: str, top_k: Optional[int] = None
    ) -> list[FusedResult]:
        """Run BM25-only retrieval (no visual component)."""
        top_k = top_k or self.settings.top_k
        bm25_results = self.bm25.search(query, top_k=top_k)

        return [
            FusedResult(
                document_id=r.doc_id,
                document_name="",
                page_number=r.page_number,
                visual_score=0.0,
                lexical_score=r.score,
                fused_score=r.score,
                image_path="",
                extracted_text=r.extracted_text,
            )
            for r in bm25_results
        ]

    def retrieve_visual_only(
        self,
        query_embedding: list[list[float]],
        top_k: Optional[int] = None,
        doc_filter: Optional[str] = None,
    ) -> list[FusedResult]:
        """Run visual-only retrieval (no BM25 component)."""
        top_k = top_k or self.settings.top_k
        visual_results = self.qdrant.search(
            query_embedding=query_embedding,
            top_k=top_k,
            doc_filter=doc_filter,
        )

        return [
            FusedResult(
                document_id=r.get("document_id", ""),
                document_name=r.get("document_name", ""),
                page_number=r.get("page_number", 0),
                visual_score=r.get("score", 0.0),
                lexical_score=0.0,
                fused_score=r.get("score", 0.0),
                image_path=r.get("image_path", ""),
                extracted_text=r.get("extracted_text", ""),
            )
            for r in visual_results
        ]
