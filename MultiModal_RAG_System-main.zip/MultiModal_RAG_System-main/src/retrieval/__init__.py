"""Retrieval subpackage — Late interaction and hybrid fusion."""
