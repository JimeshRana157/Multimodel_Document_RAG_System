"""
Late Interaction (MaxSim) Scoring and Patch Relevance Maps

Implements ColBERT-style late interaction scoring:
    S(q, d) = Σᵢ maxⱼ (qᵢ · dⱼᵀ)

Provides patch-level relevance computation for visual heatmap overlays.
"""

import logging
import math
from pathlib import Path
from typing import Optional

import numpy as np
import torch
from PIL import Image

logger = logging.getLogger(__name__)


class MaxSimScorer:
    """ColBERT-style late interaction scorer using MaxSim."""

    @staticmethod
    @torch.inference_mode()
    def score(
        query_vectors: torch.Tensor,
        page_vectors: torch.Tensor,
    ) -> float:
        """
        Compute MaxSim late interaction score between a query and a document page.

        S(q, d) = Σᵢ maxⱼ (qᵢ · dⱼᵀ)

        Args:
            query_vectors: Query multi-vector [num_query_tokens, embed_dim]
            page_vectors: Page multi-vector [num_patches, embed_dim]

        Returns:
            MaxSim similarity score (float).
        """
        if query_vectors.dim() == 3:
            query_vectors = query_vectors.squeeze(0)
        if page_vectors.dim() == 3:
            page_vectors = page_vectors.squeeze(0)

        # Normalize for cosine similarity
        q_norm = torch.nn.functional.normalize(query_vectors.float(), dim=-1)
        d_norm = torch.nn.functional.normalize(page_vectors.float(), dim=-1)

        # [num_query_tokens, num_patches]
        sim_matrix = torch.matmul(q_norm, d_norm.T)

        # MaxSim: for each query token, take max similarity across all patches
        max_sim_per_token = sim_matrix.max(dim=-1).values  # [num_query_tokens]

        # Sum across query tokens
        return max_sim_per_token.sum().item()

    @staticmethod
    @torch.inference_mode()
    def score_batch(
        query_vectors: torch.Tensor,
        all_page_vectors: list[torch.Tensor],
    ) -> list[float]:
        """
        Compute MaxSim scores for a query against multiple pages.

        Args:
            query_vectors: Query multi-vector [num_query_tokens, embed_dim]
            all_page_vectors: List of page multi-vectors, each [num_patches, embed_dim]

        Returns:
            List of MaxSim scores, one per page.
        """
        scores = []
        for page_vectors in all_page_vectors:
            s = MaxSimScorer.score(query_vectors, page_vectors)
            scores.append(s)
        return scores

    @staticmethod
    @torch.inference_mode()
    def compute_patch_relevance(
        query_vectors: torch.Tensor,
        page_vectors: torch.Tensor,
        image_width: int,
        image_height: int,
        patch_grid: Optional[tuple[int, int]] = None,
    ) -> np.ndarray:
        """
        Compute per-patch relevance scores for heatmap visualization.

        For each patch position j, computes:
            relevance_j = maxᵢ (qᵢ · dⱼ)

        This shows which image regions are most relevant to the query.

        Args:
            query_vectors: [num_query_tokens, embed_dim]
            page_vectors: [num_patches, embed_dim]
            image_width: Original image width in pixels.
            image_height: Original image height in pixels.
            patch_grid: (rows, cols) patch grid layout. If None, inferred as square grid.

        Returns:
            2D numpy array (rows, cols) of relevance scores, normalized to [0, 1].
        """
        if query_vectors.dim() == 3:
            query_vectors = query_vectors.squeeze(0)
        if page_vectors.dim() == 3:
            page_vectors = page_vectors.squeeze(0)

        num_patches = page_vectors.shape[0]

        # Infer patch grid if not provided
        if patch_grid is None:
            grid_side = int(math.sqrt(num_patches))
            if grid_side * grid_side == num_patches:
                patch_grid = (grid_side, grid_side)
            else:
                # Try common ColPali grid sizes (32x32=1024, etc.)
                # For non-square, estimate closest rectangle
                rows = int(math.sqrt(num_patches * image_height / image_width))
                cols = num_patches // rows if rows > 0 else num_patches
                while rows * cols < num_patches and rows > 0:
                    cols += 1
                patch_grid = (rows, cols)
                logger.debug(
                    "Inferred patch grid %s for %d patches", patch_grid, num_patches
                )

        grid_rows, grid_cols = patch_grid
        usable_patches = min(num_patches, grid_rows * grid_cols)

        # Normalize
        q_norm = torch.nn.functional.normalize(query_vectors.float(), dim=-1)
        d_norm = torch.nn.functional.normalize(page_vectors[:usable_patches].float(), dim=-1)

        # [num_query_tokens, usable_patches]
        sim_matrix = torch.matmul(q_norm, d_norm.T)

        # For each patch, max similarity across query tokens
        patch_relevance = sim_matrix.max(dim=0).values  # [usable_patches]

        # Reshape to grid
        relevance_np = patch_relevance.cpu().numpy()

        # Pad if needed
        if len(relevance_np) < grid_rows * grid_cols:
            padded = np.zeros(grid_rows * grid_cols)
            padded[: len(relevance_np)] = relevance_np
            relevance_np = padded

        relevance_grid = relevance_np[: grid_rows * grid_cols].reshape(
            grid_rows, grid_cols
        )

        # Normalize to [0, 1]
        rmin = relevance_grid.min()
        rmax = relevance_grid.max()
        if rmax > rmin:
            relevance_grid = (relevance_grid - rmin) / (rmax - rmin)
        else:
            relevance_grid = np.zeros_like(relevance_grid)

        return relevance_grid

    @staticmethod
    def generate_heatmap_overlay(
        image_path: str | Path,
        relevance_map: np.ndarray,
        alpha: float = 0.4,
        colormap: str = "jet",
        output_path: Optional[str | Path] = None,
    ) -> Image.Image:
        """
        Create a heatmap overlay on a page image.

        Args:
            image_path: Path to the original page image.
            relevance_map: 2D numpy array of relevance scores [0, 1].
            alpha: Transparency of the heatmap overlay (0=transparent, 1=opaque).
            colormap: Matplotlib colormap name.
            output_path: If provided, saves the overlay image to this path.

        Returns:
            PIL Image with heatmap overlay.
        """
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib as mpl

        # Load original image
        original = Image.open(image_path).convert("RGB")
        img_width, img_height = original.size

        # Create heatmap
        cmap = mpl.colormaps[colormap]
        heatmap_colored = cmap(relevance_map)  # [rows, cols, 4] RGBA
        heatmap_rgba = (heatmap_colored * 255).astype(np.uint8)
        heatmap_img = Image.fromarray(heatmap_rgba, "RGBA")

        # Resize heatmap to match image size
        heatmap_resized = heatmap_img.resize(
            (img_width, img_height), Image.Resampling.BILINEAR
        )

        # Set alpha channel
        r, g, b, a = heatmap_resized.split()
        a = a.point(lambda x: int(x * alpha))
        heatmap_resized = Image.merge("RGBA", (r, g, b, a))

        # Composite
        original_rgba = original.convert("RGBA")
        composite = Image.alpha_composite(original_rgba, heatmap_resized)
        result = composite.convert("RGB")

        if output_path:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            result.save(str(output_path))
            logger.info("Saved heatmap overlay to %s", output_path)

        return result
