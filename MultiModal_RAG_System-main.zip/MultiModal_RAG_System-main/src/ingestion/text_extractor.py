import logging
from dataclasses import dataclass
from pathlib import Path
from typing import List

import fitz  # PyMuPDF

logger = logging.getLogger(__name__)

@dataclass
class PageText:
    """Extracted text and tables from a single page."""
    page_number: int
    raw_text: str
    tables: List[List[List[str]]]

class TextExtractor:
    """Extracts text and tables from PDF documents page by page."""
    
    def extract_text(self, pdf_path: Path) -> List[PageText]:
        """
        Extracts text and tables from a PDF document.
        
        Args:
            pdf_path: Path to the PDF file.
            
        Returns:
            A list of PageText objects containing extracted text and tables for each page.
        """
        if not pdf_path.exists():
            raise FileNotFoundError(f"File not found: {pdf_path}")
            
        logger.info(f"Extracting text from {pdf_path.name}")
        pages_content = []
        
        try:
            doc = fitz.open(pdf_path)
            
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                
                # Extract raw text
                raw_text = page.get_text("text")
                
                # Extract tables using PyMuPDF's built-in table finder
                tables_data = []
                tables = page.find_tables()
                if tables and tables.tables:
                    for table in tables.tables:
                        # Extract table as list of rows (list of cells)
                        extracted_table = table.extract()
                        
                        # Clean up None values that extract() might return for empty cells
                        cleaned_table = []
                        for row in extracted_table:
                            cleaned_row = [str(cell) if cell is not None else "" for cell in row]
                            cleaned_table.append(cleaned_row)
                            
                        tables_data.append(cleaned_table)
                        
                pages_content.append(
                    PageText(
                        page_number=page_num,
                        raw_text=raw_text,
                        tables=tables_data
                    )
                )
                
            doc.close()
            
        except Exception as e:
            logger.error(f"Error extracting text from {pdf_path}: {e}")
            raise
            
        return pages_content
