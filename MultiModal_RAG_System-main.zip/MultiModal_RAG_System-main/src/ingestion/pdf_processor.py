import hashlib
import json
import logging
import shutil
import uuid
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import List

import fitz  # PyMuPDF

from src.config import get_settings

logger = logging.getLogger(__name__)

@dataclass
class DocumentMetadata:
    """Metadata for a processed PDF document."""
    document_id: str
    document_name: str
    total_pages: int
    page_image_paths: List[Path]
    upload_timestamp: str
    file_hash: str

class PDFProcessor:
    """Processes PDF documents into rendered page images and extracts metadata."""
    
    def __init__(self):
        self.settings = get_settings()
        self.settings.page_renders_dir.mkdir(parents=True, exist_ok=True)
        self.settings.index_dir.mkdir(parents=True, exist_ok=True)
        
    def _compute_hash(self, pdf_path: Path) -> str:
        """Computes the SHA256 hash of a file."""
        sha256 = hashlib.sha256()
        with open(pdf_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
        
    def _is_empty_page(self, page: fitz.Page, pixmap: fitz.Pixmap) -> bool:
        """Detects if a page is empty (all white or empty text)."""
        text = page.get_text("text").strip()
        if text:
            return False
            
        # Check if image is uniformly white
        samples = pixmap.samples
        if not samples:
            return True
            
        # If all samples are 255 (white)
        if all(s == 255 for s in samples):
            return True
            
        return False

    def process_pdf(self, pdf_path: Path, dpi: int = 300) -> DocumentMetadata:
        """
        Processes a PDF document.
        
        Args:
            pdf_path: Path to the PDF file.
            dpi: DPI for rendering page images.
            
        Returns:
            DocumentMetadata object containing information about the processed PDF.
            
        Raises:
            ValueError: If the file size exceeds the maximum allowed or if it's corrupted.
        """
        if not pdf_path.exists():
            raise FileNotFoundError(f"File not found: {pdf_path}")
            
        file_size = pdf_path.stat().st_size
        if file_size > self.settings.max_upload_size:
            raise ValueError(f"File size {file_size} exceeds maximum allowed {self.settings.max_upload_size}")
            
        file_hash = self._compute_hash(pdf_path)
        
        existing_docs = self.list_documents()
        for doc in existing_docs:
            if doc.file_hash == file_hash:
                logger.info(f"Document {pdf_path.name} already processed as {doc.document_id}")
                return doc
                
        document_id = str(uuid.uuid4())
        doc_render_dir = self.settings.page_renders_dir / document_id
        doc_render_dir.mkdir(parents=True, exist_ok=True)
        
        page_image_paths = []
        
        try:
            doc = fitz.open(pdf_path)
            total_pages = len(doc)
            
            for page_num in range(total_pages):
                page = doc.load_page(page_num)
                pixmap = page.get_pixmap(dpi=dpi)
                
                if self._is_empty_page(page, pixmap):
                    logger.warning(f"Skipping empty page {page_num} in {pdf_path.name}")
                    continue
                    
                image_path = doc_render_dir / f"page_{page_num:04d}.png"
                pixmap.save(str(image_path))
                page_image_paths.append(image_path)
                
            doc.close()
            
        except fitz.FileDataError as e:
            logger.error(f"Failed to process corrupted PDF {pdf_path}: {e}")
            shutil.rmtree(doc_render_dir, ignore_errors=True)
            raise ValueError(f"Corrupted PDF file: {e}")
        except Exception as e:
            logger.error(f"Error processing PDF {pdf_path}: {e}")
            shutil.rmtree(doc_render_dir, ignore_errors=True)
            raise
            
        metadata = DocumentMetadata(
            document_id=document_id,
            document_name=pdf_path.name,
            total_pages=total_pages,
            page_image_paths=page_image_paths,
            upload_timestamp=datetime.now(timezone.utc).isoformat(),
            file_hash=file_hash
        )
        
        self._save_metadata(metadata)
        logger.info(f"Successfully processed PDF {pdf_path.name} with {total_pages} pages")
        
        return metadata

    def _save_metadata(self, metadata: DocumentMetadata) -> None:
        """Saves document metadata to a JSON file."""
        meta_path = self.settings.index_dir / f"{metadata.document_id}_meta.json"
        
        meta_dict = asdict(metadata)
        meta_dict['page_image_paths'] = [str(p) for p in meta_dict['page_image_paths']]
        
        with open(meta_path, 'w', encoding='utf-8') as f:
            json.dump(meta_dict, f, indent=4)
            
    def process_multiple(self, pdf_paths: List[Path]) -> List[DocumentMetadata]:
        """
        Processes multiple PDF documents in batch.
        
        Args:
            pdf_paths: List of paths to PDF files.
            
        Returns:
            List of DocumentMetadata objects.
        """
        results = []
        for path in pdf_paths:
            try:
                metadata = self.process_pdf(path, dpi=self.settings.dpi)
                results.append(metadata)
            except Exception as e:
                logger.error(f"Failed to process {path}: {e}")
        return results

    def load_metadata(self, doc_id: str) -> DocumentMetadata:
        """
        Loads document metadata from JSON file.
        
        Args:
            doc_id: The document ID.
            
        Returns:
            DocumentMetadata object.
            
        Raises:
            FileNotFoundError: If metadata file doesn't exist.
        """
        meta_path = self.settings.index_dir / f"{doc_id}_meta.json"
        if not meta_path.exists():
            raise FileNotFoundError(f"Metadata file not found for document {doc_id}")
            
        with open(meta_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        data['page_image_paths'] = [Path(p) for p in data['page_image_paths']]
        return DocumentMetadata(**data)

    def list_documents(self) -> List[DocumentMetadata]:
        """
        Lists all processed documents by scanning the index directory.
        
        Returns:
            List of DocumentMetadata objects.
        """
        documents = []
        for meta_file in self.settings.index_dir.glob("*_meta.json"):
            try:
                doc_id = meta_file.name.replace("_meta.json", "")
                metadata = self.load_metadata(doc_id)
                documents.append(metadata)
            except Exception as e:
                logger.error(f"Failed to load metadata from {meta_file}: {e}")
        return documents

    def delete_document(self, doc_id: str) -> None:
        """
        Deletes a document's rendered pages and metadata.
        
        Args:
            doc_id: The document ID to delete.
        """
        meta_path = self.settings.index_dir / f"{doc_id}_meta.json"
        if meta_path.exists():
            meta_path.unlink()
            
        doc_render_dir = self.settings.page_renders_dir / doc_id
        if doc_render_dir.exists():
            shutil.rmtree(doc_render_dir)
            
        logger.info(f"Deleted document {doc_id}")
