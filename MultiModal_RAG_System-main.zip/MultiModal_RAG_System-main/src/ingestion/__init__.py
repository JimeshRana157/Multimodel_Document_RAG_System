"""Ingestion subpackage — PDF processing and text extraction."""
