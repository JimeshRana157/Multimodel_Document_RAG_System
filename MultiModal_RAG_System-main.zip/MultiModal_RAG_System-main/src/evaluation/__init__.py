"""Evaluation subpackage — RAG benchmarking and metrics."""
