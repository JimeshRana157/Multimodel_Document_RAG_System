"""
Evaluation and Benchmarking Module for Multimodal RAG

Implements mathematically rigorous evaluation:
- Recall@1, Recall@3, Recall@5
- Mean Reciprocal Rank (MRR)
- NDCG@5 (Normalized Discounted Cumulative Gain)
- Independent latency profiling: P50, P95, Mean, Min, Max
"""

import json
import time
import math
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, List, Tuple, Dict, Any

import numpy as np
import torch

from src.config import get_settings
from src.retrieval.hybrid_fusion import HybridRetriever, FusedResult

logger = logging.getLogger(__name__)


@dataclass
class EvalQuery:
    """Represents an evaluation query with ground-truth relevant pages."""
    question: str
    relevant_doc_ids: List[str]
    relevant_pages: List[Tuple[str, int]]  # [(doc_id_or_name, page_number)]
    ground_truth_answer: Optional[str] = None


@dataclass
class LatencyProfile:
    """Detailed latency statistics in milliseconds."""
    mean_ms: float
    p50_ms: float
    p95_ms: float
    min_ms: float
    max_ms: float


@dataclass
class RetrievalMetrics:
    """Standard information retrieval performance metrics."""
    recall_at_1: float
    recall_at_3: float
    recall_at_5: float
    mrr: float
    ndcg_at_5: float
    latency: LatencyProfile


@dataclass
class EvalResult:
    """Comprehensive benchmark result across an evaluation run."""
    pipeline_name: str
    metrics: RetrievalMetrics
    num_queries: int
    evaluated_at: str


class RAGEvaluator:
    """
    Evaluates Multimodal RAG retrieval and generation performance.
    """

    def __init__(
        self,
        hybrid_retriever: HybridRetriever,
        colpali_embedder: Optional[Any] = None,
        vision_llm: Optional[Any] = None,
    ):
        self.hybrid_retriever = hybrid_retriever
        self.colpali_embedder = colpali_embedder
        self.vision_llm = vision_llm
        self.settings = get_settings()

    def generate_evaluation_template(self, output_path: Path) -> Path:
        """Creates a JSON evaluation template with example queries."""
        template_data = [
            {
                "question": "What is the calibration imperative described in the report?",
                "relevant_doc_ids": ["The_Calibration_Imperative.pdf"],
                "relevant_pages": [["The_Calibration_Imperative.pdf", 1], ["The_Calibration_Imperative.pdf", 2]],
                "ground_truth_answer": "Calibration is the process of comparing a measurement against a reference standard."
            },
            {
                "question": "What are the major neural network results reported in GeoAI?",
                "relevant_doc_ids": ["GeoAI_minor.pdf"],
                "relevant_pages": [["GeoAI_minor.pdf", 3], ["GeoAI_minor.pdf", 4]],
                "ground_truth_answer": "The models achieved an R-squared of 0.89 across spatial clusters."
            }
        ]

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(template_data, f, indent=4)

        logger.info("Evaluation template generated at %s", output_path)
        return output_path

    def load_eval_dataset(self, path: Path) -> List[EvalQuery]:
        """Loads and validates evaluation dataset from JSON file."""
        if not path.exists():
            raise FileNotFoundError(f"Evaluation dataset not found at {path}")

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        queries = []
        for item in data:
            if "question" not in item or "relevant_pages" not in item:
                continue

            rel_pages = [(str(p[0]), int(p[1])) for p in item["relevant_pages"]]
            queries.append(
                EvalQuery(
                    question=item["question"],
                    relevant_doc_ids=item.get("relevant_doc_ids", []),
                    relevant_pages=rel_pages,
                    ground_truth_answer=item.get("ground_truth_answer"),
                )
            )

        logger.info("Loaded %d evaluation queries from %s", len(queries), path)
        return queries

    def _compute_recall_at_k(
        self,
        retrieved: List[Tuple[str, int]],
        relevant: List[Tuple[str, int]],
        k: int,
    ) -> float:
        """Recall@K = |Retrieved@K ∩ Relevant| / |Relevant|."""
        if not relevant:
            return 0.0

        retrieved_k = retrieved[:k]
        rel_set = {(str(d).lower(), p) for d, p in relevant}
        ret_set = {(str(d).lower(), p) for d, p in retrieved_k}

        # Match either doc_id or doc_name
        hits = 0
        for r_doc, r_page in rel_set:
            for ret_doc, ret_page in ret_set:
                if (r_doc in ret_doc or ret_doc in r_doc) and r_page == ret_page:
                    hits += 1
                    break

        return min(hits / len(rel_set), 1.0)

    def _compute_mrr(
        self,
        retrieved: List[Tuple[str, int]],
        relevant: List[Tuple[str, int]],
    ) -> float:
        """Mean Reciprocal Rank: 1 / rank of first relevant result."""
        if not relevant:
            return 0.0

        rel_set = {(str(d).lower(), p) for d, p in relevant}
        for rank_idx, (ret_doc, ret_page) in enumerate(retrieved, start=1):
            ret_doc_lower = str(ret_doc).lower()
            for r_doc, r_page in rel_set:
                if (r_doc in ret_doc_lower or ret_doc_lower in r_doc) and r_page == ret_page:
                    return 1.0 / rank_idx
        return 0.0

    def _compute_ndcg_at_k(
        self,
        retrieved: List[Tuple[str, int]],
        relevant: List[Tuple[str, int]],
        k: int = 5,
    ) -> float:
        """NDCG@K with binary relevance."""
        if not relevant:
            return 0.0

        rel_set = {(str(d).lower(), p) for d, p in relevant}
        retrieved_k = retrieved[:k]

        dcg = 0.0
        for i, (ret_doc, ret_page) in enumerate(retrieved_k, start=1):
            ret_doc_lower = str(ret_doc).lower()
            is_hit = False
            for r_doc, r_page in rel_set:
                if (r_doc in ret_doc_lower or ret_doc_lower in r_doc) and r_page == ret_page:
                    is_hit = True
                    break
            if is_hit:
                dcg += 1.0 / math.log2(i + 1)

        # Ideal DCG
        ideal_hits = min(len(relevant), k)
        idcg = sum(1.0 / math.log2(i + 1) for i in range(1, ideal_hits + 1))

        return dcg / idcg if idcg > 0 else 0.0

    def _profile_latencies(self, latencies_ms: List[float]) -> LatencyProfile:
        """Computes statistical percentiles from list of latency measurements."""
        if not latencies_ms:
            return LatencyProfile(0.0, 0.0, 0.0, 0.0, 0.0)

        arr = np.array(latencies_ms)
        return LatencyProfile(
            mean_ms=float(np.mean(arr)),
            p50_ms=float(np.percentile(arr, 50)),
            p95_ms=float(np.percentile(arr, 95)),
            min_ms=float(np.min(arr)),
            max_ms=float(np.max(arr)),
        )

    def evaluate_retrieval(
        self,
        eval_queries: List[EvalQuery],
        mode: str = "hybrid",
        top_k: int = 5,
    ) -> RetrievalMetrics:
        """
        Runs retrieval benchmark with strictly isolated, independent timers.
        """
        r1_list, r3_list, r5_list = [], [], []
        mrr_list, ndcg_list = [], []
        latencies = []

        for q in eval_queries:
            # Independent timing
            t0 = time.perf_counter()

            if mode == "bm25":
                results = self.hybrid_retriever.retrieve_bm25_only(q.question, top_k=top_k)
            elif mode == "visual":
                query_emb = None
                if self.colpali_embedder:
                    emb_tensor = self.colpali_embedder.embed_query(q.question)
                    query_emb = emb_tensor.squeeze(0).tolist()
                results = self.hybrid_retriever.retrieve_visual_only(query_embedding=query_emb, top_k=top_k)
            else:  # hybrid
                query_emb = None
                if self.colpali_embedder:
                    emb_tensor = self.colpali_embedder.embed_query(q.question)
                    query_emb = emb_tensor.squeeze(0).tolist()
                results = self.hybrid_retriever.retrieve(
                    query=q.question,
                    query_embedding=query_emb,
                    top_k=top_k,
                )

            elapsed_ms = (time.perf_counter() - t0) * 1000.0
            latencies.append(elapsed_ms)

            retrieved_tuples = [
                (r.document_name or r.document_id, r.page_number)
                for r in results
            ]

            r1_list.append(self._compute_recall_at_k(retrieved_tuples, q.relevant_pages, k=1))
            r3_list.append(self._compute_recall_at_k(retrieved_tuples, q.relevant_pages, k=3))
            r5_list.append(self._compute_recall_at_k(retrieved_tuples, q.relevant_pages, k=5))
            mrr_list.append(self._compute_mrr(retrieved_tuples, q.relevant_pages))
            ndcg_list.append(self._compute_ndcg_at_k(retrieved_tuples, q.relevant_pages, k=5))

        return RetrievalMetrics(
            recall_at_1=float(np.mean(r1_list)) if r1_list else 0.0,
            recall_at_3=float(np.mean(r3_list)) if r3_list else 0.0,
            recall_at_5=float(np.mean(r5_list)) if r5_list else 0.0,
            mrr=float(np.mean(mrr_list)) if mrr_list else 0.0,
            ndcg_at_5=float(np.mean(ndcg_list)) if ndcg_list else 0.0,
            latency=self._profile_latencies(latencies),
        )

    def run_full_benchmark(
        self,
        eval_queries: List[EvalQuery],
        top_k: int = 5,
    ) -> List[EvalResult]:
        """Runs evaluation across BM25, ColPali Visual, and Hybrid RRF."""
        modes = [
            ("BM25 Lexical Only", "bm25"),
            ("ColPali Visual Only", "visual"),
            ("Hybrid RRF (0.7/0.3)", "hybrid"),
        ]

        from datetime import datetime, timezone
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

        results = []
        for name, mode_code in modes:
            metrics = self.evaluate_retrieval(eval_queries, mode=mode_code, top_k=top_k)
            results.append(
                EvalResult(
                    pipeline_name=name,
                    metrics=metrics,
                    num_queries=len(eval_queries),
                    evaluated_at=timestamp,
                )
            )

        return results
