"""
Multimodal Financial RAG — Central Configuration

Reads all settings from environment variables / .env file.
Auto-detects hardware (CUDA/CPU) and sets appropriate defaults.
"""

import os
import logging
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

import torch
from dotenv import load_dotenv

# Load .env from project root
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(_PROJECT_ROOT / ".env")

logger = logging.getLogger(__name__)


def _resolve_device(device_str: str) -> str:
    """Resolve device string to actual torch device."""
    if device_str == "auto":
        if torch.cuda.is_available():
            return "cuda"
        elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return "mps"
        else:
            return "cpu"
    return device_str


def _resolve_dtype(precision: str, device: str) -> torch.dtype:
    """Resolve precision string to torch dtype."""
    if precision == "auto":
        if device == "cuda" and torch.cuda.is_bf16_supported():
            return torch.bfloat16
        elif device == "cuda":
            return torch.float16
        else:
            return torch.float32
    mapping = {
        "bf16": torch.bfloat16,
        "fp16": torch.float16,
        "fp32": torch.float32,
    }
    return mapping.get(precision, torch.float32)


@dataclass
class Settings:
    """Application settings loaded from environment."""

    # --- Qdrant ---
    qdrant_url: str = field(default_factory=lambda: os.getenv("QDRANT_URL", "http://localhost:6333"))
    qdrant_collection: str = field(default_factory=lambda: os.getenv("QDRANT_COLLECTION", "financial_pages"))
    qdrant_local_path: str = field(default_factory=lambda: os.getenv(
        "QDRANT_LOCAL_PATH",
        str(_PROJECT_ROOT / "data" / "qdrant_storage"),
    ))

    # --- ColPali Model ---
    model_name: str = field(default_factory=lambda: os.getenv("MODEL_NAME", "vidore/colpali-v1.2"))

    # --- VLM ---
    vlm_endpoint: str = field(default_factory=lambda: os.getenv("VLM_ENDPOINT", "http://localhost:11434/v1"))
    vlm_model: str = field(default_factory=lambda: os.getenv("VLM_MODEL", "llava:13b"))
    vlm_api_key: str = field(default_factory=lambda: os.getenv("VLM_API_KEY", "not-needed"))

    # --- Hardware ---
    device: str = field(default_factory=lambda: _resolve_device(os.getenv("DEVICE", "auto")))
    batch_size: int = field(default_factory=lambda: int(os.getenv("BATCH_SIZE", "4")))
    precision: str = field(default_factory=lambda: os.getenv("PRECISION", "auto"))

    # --- Retrieval ---
    top_k: int = field(default_factory=lambda: int(os.getenv("TOP_K", "5")))
    rrf_k: int = field(default_factory=lambda: int(os.getenv("RRF_K", "60")))
    visual_weight: float = field(default_factory=lambda: float(os.getenv("VISUAL_WEIGHT", "0.7")))
    lexical_weight: float = field(default_factory=lambda: float(os.getenv("LEXICAL_WEIGHT", "0.3")))

    # --- PDF Processing ---
    dpi: int = field(default_factory=lambda: int(os.getenv("DPI", "300")))
    max_upload_size: int = field(default_factory=lambda: int(os.getenv("MAX_UPLOAD_SIZE", "104857600")))  # 100MB
    max_files: int = field(default_factory=lambda: int(os.getenv("MAX_FILES", "15")))

    # --- API ---
    api_host: str = field(default_factory=lambda: os.getenv("API_HOST", "0.0.0.0"))
    api_port: int = field(default_factory=lambda: int(os.getenv("API_PORT", "8000")))
    cors_origins: str = field(default_factory=lambda: os.getenv("CORS_ORIGINS", "*"))

    # --- Paths ---
    project_root: Path = field(default_factory=lambda: _PROJECT_ROOT)
    data_dir: Path = field(
        default_factory=lambda: Path(os.getenv("DATA_DIR", str(_PROJECT_ROOT / "data")))
    )
    index_dir: Path = field(
        default_factory=lambda: Path(
            os.getenv("INDEX_DIR", str(_PROJECT_ROOT / "data" / "index"))
        )
    )
    page_renders_dir: Path = field(
        default_factory=lambda: Path(
            os.getenv("PAGE_RENDERS_DIR", str(_PROJECT_ROOT / "data" / "page_renders"))
        )
    )
    raw_uploads_dir: Path = field(
        default_factory=lambda: Path(
            os.getenv("RAW_UPLOADS_DIR", str(_PROJECT_ROOT / "data" / "raw_uploads"))
        )
    )

    def __post_init__(self):
        """Create directories and resolve dtype after init."""
        self.dtype: torch.dtype = _resolve_dtype(self.precision, self.device)

        # Ensure all data directories exist
        for dir_path in [
            self.data_dir,
            self.index_dir,
            self.page_renders_dir,
            self.raw_uploads_dir,
        ]:
            dir_path.mkdir(parents=True, exist_ok=True)

        logger.info(
            "Settings initialized: device=%s, dtype=%s, model=%s",
            self.device,
            self.dtype,
            self.model_name,
        )

    @property
    def cors_origin_list(self) -> list[str]:
        """Parse CORS origins into a list."""
        return [o.strip() for o in self.cors_origins.split(",")]


# Singleton instance
_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get or create the singleton Settings instance."""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
