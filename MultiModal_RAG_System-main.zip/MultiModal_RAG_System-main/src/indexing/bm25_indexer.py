import logging
import pickle
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple, Dict, Any

from rank_bm25 import BM25Okapi

from src.config import get_settings
from src.ingestion.text_extractor import PageText

logger = logging.getLogger(__name__)

# Basic general stopwords list
GENERAL_STOPWORDS = {
    'the', 'is', 'at', 'which', 'on', 'in', 'a', 'an', 'and', 'or', 'to', 'for', 'of', 'with', 'by',
    'as', 'this', 'that', 'these', 'those', 'from', 'it', 'its', 'they', 'their', 'we', 'our',
    'be', 'was', 'were', 'has', 'have', 'had', 'are', 'not', 'but', 'all', 'any', 'other', 'such'
}

@dataclass
class BM25Result:
    """Result from a BM25 search query."""
    doc_id: str
    page_number: int
    score: float
    extracted_text: str

class BM25Index:
    """BM25 Lexical Index for document search."""
    
    def __init__(self):
        self.settings = get_settings()
        self.index_path = self.settings.index_dir / 'bm25_index.pkl'
        
        self.corpus: List[List[str]] = []
        self.page_ids: List[Tuple[str, int]] = []
        self.raw_texts: List[str] = []
        self.bm25: BM25Okapi = None
        
        if self.index_path.exists():
            self.load(self.index_path)
            
    def _tokenize(self, text: str) -> List[str]:
        """
        Tokenizes text by lowercasing, splitting on non-alphanumeric chars,
        and removing stopwords.
        """
        if not text:
            return []
            
        clean_text = re.sub(r'[^a-zA-Z0-9\s]', ' ', text.lower())
        
        tokens = [
            token for token in clean_text.split()
            if token and token not in GENERAL_STOPWORDS
        ]
        
        return tokens

    def _rebuild_index(self) -> None:
        """Recreates the BM25Okapi instance from the current corpus."""
        if self.corpus:
            self.bm25 = BM25Okapi(self.corpus)
        else:
            self.bm25 = None
            
    def add_document(self, doc_id: str, pages: List[PageText]) -> None:
        """
        Adds a document's pages to the index.
        
        Args:
            doc_id: The document ID.
            pages: List of PageText objects.
        """
        self.remove_document(doc_id, auto_save=False)
        
        for page in pages:
            full_text = page.raw_text
            
            for table in page.tables:
                for row in table:
                    full_text += " " + " ".join(row)
                    
            tokens = self._tokenize(full_text)
            
            self.corpus.append(tokens)
            self.page_ids.append((doc_id, page.page_number))
            self.raw_texts.append(full_text)
            
        self._rebuild_index()
        self.save(self.index_path)
        logger.info(f"Added document {doc_id} with {len(pages)} pages to BM25 index")

    def remove_document(self, doc_id: str, auto_save: bool = True) -> None:
        """
        Removes all pages for a document and rebuilds the index.
        
        Args:
            doc_id: The document ID to remove.
            auto_save: Whether to auto-save after removal.
        """
        indices_to_keep = [i for i, (d_id, _) in enumerate(self.page_ids) if d_id != doc_id]
        
        if len(indices_to_keep) == len(self.page_ids):
            return
            
        self.corpus = [self.corpus[i] for i in indices_to_keep]
        self.page_ids = [self.page_ids[i] for i in indices_to_keep]
        self.raw_texts = [self.raw_texts[i] for i in indices_to_keep]
        
        self._rebuild_index()
        
        if auto_save:
            self.save(self.index_path)
            
        logger.info(f"Removed document {doc_id} from BM25 index")

    def search(self, query: str, top_k: int = 5) -> List[BM25Result]:
        """
        Searches the index for the given query.
        
        Args:
            query: The search query.
            top_k: Number of results to return.
            
        Returns:
            List of BM25Result objects with normalized scores.
        """
        if not self.bm25 or not self.corpus:
            return []
            
        query_tokens = self._tokenize(query)
        if not query_tokens:
            return []
            
        scores = self.bm25.get_scores(query_tokens)
        
        top_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]
        
        results = []
        for idx in top_indices:
            score = scores[idx]
            if score <= 0:
                continue
                
            doc_id, page_num = self.page_ids[idx]
            results.append(
                BM25Result(
                    doc_id=doc_id,
                    page_number=page_num,
                    score=score,
                    extracted_text=self.raw_texts[idx]
                )
            )
            
        if results:
            scores_list = [r.score for r in results]
            min_score = min(scores_list)
            max_score = max(scores_list)
            
            for result in results:
                if max_score > min_score:
                    result.score = (result.score - min_score) / (max_score - min_score)
                else:
                    result.score = 1.0
                    
        return results

    def save(self, path: Path) -> None:
        """Saves the index to disk."""
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            'corpus': self.corpus,
            'page_ids': self.page_ids,
            'raw_texts': self.raw_texts
        }
        with open(path, 'wb') as f:
            pickle.dump(data, f)
        logger.info(f"Saved BM25 index to {path}")

    def load(self, path: Path) -> None:
        """Loads the index from disk."""
        if not path.exists():
            return
            
        with open(path, 'rb') as f:
            data = pickle.load(f)
            
        self.corpus = data.get('corpus', [])
        self.page_ids = data.get('page_ids', [])
        self.raw_texts = data.get('raw_texts', [])
        
        self._rebuild_index()
        logger.info(f"Loaded BM25 index from {path} with {len(self.corpus)} pages")
