import hashlib
import logging
from typing import List, Dict, Optional, Union

from qdrant_client import QdrantClient, models
from src.config import get_settings

logger = logging.getLogger(__name__)

class QdrantStore:
    """
    Qdrant vector store manager for persistent storage with multivector/late-interaction support.
    """

    def __init__(self) -> None:
        """
        Initializes the Qdrant connection. Tries connecting to settings.qdrant_url first,
        and falls back to local persistent Qdrant at settings.qdrant_local_path on failure.
        """
        self.settings = get_settings()
        self.collection_name = self.settings.qdrant_collection
        self.client: Optional[QdrantClient] = None

        try:
            if self.settings.qdrant_url:
                self.client = QdrantClient(url=self.settings.qdrant_url)
                # Test connection
                self.client.get_collections()
                logger.info(f"Connected to remote Qdrant at {self.settings.qdrant_url}")
            else:
                raise ValueError("qdrant_url not provided")
        except Exception as e:
            logger.warning(f"Failed to connect to remote Qdrant: {e}. Falling back to local Qdrant at {self.settings.qdrant_local_path}")
            self.client = QdrantClient(path=str(self.settings.qdrant_local_path))
            logger.info(f"Connected to local Qdrant at {self.settings.qdrant_local_path}")

    def health_check(self) -> bool:
        """
        Returns True if Qdrant is responding.
        """
        try:
            if self.client:
                self.client.get_collections()
                return True
            return False
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False

    def ensure_collection(self, embed_dim: int) -> None:
        """
        Creates the collection if it doesn't exist with multivector configuration.
        """
        if not self.client:
            raise RuntimeError("QdrantClient is not initialized")

        collections_response = self.client.get_collections()
        collection_names = [collection.name for collection in collections_response.collections]

        if self.collection_name in collection_names:
            logger.info(f"Collection '{self.collection_name}' already exists.")
            return

        logger.info(f"Creating collection '{self.collection_name}' with multivector support.")
        self.client.create_collection(
            collection_name=self.collection_name,
            vectors_config=models.VectorParams(
                size=embed_dim,
                distance=models.Distance.COSINE,
                multivector_config=models.MultiVectorConfig(
                    comparator=models.MultiVectorComparator.MAX_SIM
                )
            )
        )

    def get_collection_info(self) -> dict:
        """
        Returns collection stats (points_count, vectors_count, status).
        """
        if not self.client:
            raise RuntimeError("QdrantClient is not initialized")

        info = self.client.get_collection(self.collection_name)
        return {
            "points_count": info.points_count,
            "vectors_count": getattr(info, 'vectors_count', info.points_count),
            "status": info.status.value if hasattr(info.status, 'value') else info.status
        }

    def delete_collection(self) -> None:
        """
        Drops the collection.
        """
        if not self.client:
            raise RuntimeError("QdrantClient is not initialized")

        logger.warning(f"Deleting collection '{self.collection_name}'")
        self.client.delete_collection(self.collection_name)

    def _doc_page_hash(self, doc_id: str, page_num: int) -> int:
        """
        Deterministic hash to integer for point ID.
        """
        hash_str = f"{doc_id}_{page_num}"
        md5_hash = hashlib.md5(hash_str.encode("utf-8")).hexdigest()
        return int(md5_hash[:16], 16)

    def upsert_pages(self, page_embeddings: list[list[list[float]]], metadata_list: list[dict], batch_size: int = 64) -> int:
        """
        Upserts pages with multivector representations.
        Returns count of upserted points.
        """
        if not self.client:
            raise RuntimeError("QdrantClient is not initialized")

        if len(page_embeddings) != len(metadata_list):
            raise ValueError("Number of embeddings must match number of metadata dicts")

        points = []
        for embedding, metadata in zip(page_embeddings, metadata_list):
            doc_id = metadata["document_id"]
            page_num = metadata["page_number"]
            point_id = self._doc_page_hash(doc_id, page_num)

            points.append(
                models.PointStruct(
                    id=point_id,
                    vector=embedding,
                    payload=metadata
                )
            )

        total_upserted = 0
        for i in range(0, len(points), batch_size):
            batch = points[i:i + batch_size]
            self.client.upsert(
                collection_name=self.collection_name,
                points=batch
            )
            total_upserted += len(batch)

        return total_upserted

    def search(self, query_embedding: list[list[float]], top_k: int = 5, doc_filter: Optional[str] = None) -> list[dict]:
        """
        Uses Qdrant's native multivector search with MaxSim.
        """
        if not self.client:
            raise RuntimeError("QdrantClient is not initialized")

        if doc_filter is not None:
            query_filter = models.Filter(
                must=[
                    models.FieldCondition(
                        key="document_id",
                        match=models.MatchValue(value=doc_filter)
                    )
                ]
            )
        else:
            query_filter = None

        search_result = self.client.query_points(
            collection_name=self.collection_name,
            query=query_embedding,
            query_filter=query_filter,
            limit=top_k
        ).points

        results = []
        for hit in search_result:
            payload = hit.payload or {}
            results.append({
                "id": hit.id,
                "score": hit.score,
                "document_id": payload.get("document_id"),
                "document_name": payload.get("document_name"),
                "page_number": payload.get("page_number"),
                "image_path": payload.get("image_path"),
                "extracted_text": payload.get("extracted_text")
            })

        return results

    def delete_document(self, doc_id: str) -> int:
        """
        Deletes all points where payload.document_id == doc_id.
        Returns the count of points deleted.
        """
        if not self.client:
            raise RuntimeError("QdrantClient is not initialized")

        count_response = self.client.count(
            collection_name=self.collection_name,
            count_filter=models.Filter(
                must=[
                    models.FieldCondition(
                        key="document_id",
                        match=models.MatchValue(value=doc_id)
                    )
                ]
            )
        )
        count = count_response.count

        if count > 0:
            self.client.delete(
                collection_name=self.collection_name,
                points_selector=models.FilterSelector(
                    filter=models.Filter(
                        must=[
                            models.FieldCondition(
                                key="document_id",
                                match=models.MatchValue(value=doc_id)
                            )
                        ]
                    )
                )
            )
        return count

    def get_all_documents(self) -> list[dict]:
        """
        Scrolls through all points, groups by document_id, returns unique documents with page counts.
        """
        if not self.client:
            raise RuntimeError("QdrantClient is not initialized")

        documents = {}
        offset = None

        while True:
            scroll_result, next_offset = self.client.scroll(
                collection_name=self.collection_name,
                limit=100,
                offset=offset,
                with_payload=True,
                with_vectors=False
            )

            for record in scroll_result:
                payload = record.payload or {}
                doc_id = payload.get("document_id")
                if doc_id:
                    if doc_id not in documents:
                        documents[doc_id] = {
                            "document_id": doc_id,
                            "document_name": payload.get("document_name"),
                            "page_count": 0,
                            "total_pages": payload.get("total_pages")
                        }
                    documents[doc_id]["page_count"] += 1

            if next_offset is None:
                break
            offset = next_offset

        return list(documents.values())

    def get_point_vectors(self, point_id: int) -> list[list[float]]:
        """
        Retrieves the multivector for a specific point.
        """
        if not self.client:
            raise RuntimeError("QdrantClient is not initialized")

        records = self.client.retrieve(
            collection_name=self.collection_name,
            ids=[point_id],
            with_vectors=True
        )

        if not records:
            raise ValueError(f"Point {point_id} not found")

        vector = records[0].vector
        if isinstance(vector, list) and len(vector) > 0 and isinstance(vector[0], list):
            return vector
        elif isinstance(vector, dict):
            # fallback if named vectors are used (default un-named vector is usually empty string key)
            return list(vector.values())[0] # type: ignore
        return vector # type: ignore

    def count_points(self) -> int:
        """
        Returns total number of indexed points.
        """
        if not self.client:
            raise RuntimeError("QdrantClient is not initialized")

        count_response = self.client.count(collection_name=self.collection_name)
        return count_response.count
