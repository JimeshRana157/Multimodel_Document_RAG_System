"""Indexing subpackage — ColPali, BM25, and Qdrant indexing."""
