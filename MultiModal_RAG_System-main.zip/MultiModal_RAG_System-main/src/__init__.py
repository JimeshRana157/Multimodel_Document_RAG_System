"""Multimodal Financial RAG — Source Package."""
