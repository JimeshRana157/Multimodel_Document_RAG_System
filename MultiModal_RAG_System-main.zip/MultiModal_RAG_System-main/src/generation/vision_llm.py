import base64
import logging
import re
from dataclasses import dataclass
from typing import AsyncGenerator, Generator, List, Union, Optional

import openai
from src.config import get_settings

logger = logging.getLogger(__name__)


@dataclass
class EvidencePage:
    """Dataclass representing a single page of evidence."""
    document_name: str
    page_number: int
    image_path: str
    extracted_text: str
    fused_score: float
    document_id: Optional[str] = None
    visual_score: Optional[float] = None
    lexical_score: Optional[float] = None


class VisionLLM:
    """
    VisionLLM class for VLM-based answer generation with streaming.
    Outputs ONLY clean natural language answers, decoupled from raw citations or diagnostics.
    """

    def __init__(self) -> None:
        settings = get_settings()
        self.model_name = settings.vlm_model
        self.endpoint = settings.vlm_endpoint
        self._is_available = False

        try:
            self.client = openai.OpenAI(
                base_url=settings.vlm_endpoint,
                api_key=settings.vlm_api_key,
                timeout=5.0,
            )
            self.async_client = openai.AsyncOpenAI(
                base_url=settings.vlm_endpoint,
                api_key=settings.vlm_api_key,
                timeout=5.0,
            )
            # Check availability
            self.client.models.list()
            self._is_available = True
            logger.info("Connected to Vision LLM service at %s", settings.vlm_endpoint)
        except Exception as e:
            logger.info("External VLM service offline (%s). Using local extractive reasoning.", e)
            self._is_available = False

    def _encode_image(self, image_path: str) -> str:
        """Reads image file, returns base64-encoded data URI string."""
        try:
            with open(image_path, "rb") as image_file:
                encoded_string = base64.b64encode(image_file.read()).decode("utf-8")
                ext = image_path.split(".")[-1].lower()
                mime_type = f"image/{ext}" if ext in ["png", "jpeg", "jpg", "webp", "gif"] else "image/png"
                return f"data:{mime_type};base64,{encoded_string}"
        except Exception as e:
            logger.error("Failed to read image %s: %s", image_path, e)
            return ""

    def _prepare_messages(self, question: str, evidence_pages: List[EvidencePage]) -> list:
        system_message = {
            "role": "system",
            "content": (
                "You are an expert multimodal document intelligence assistant. "
                "Answer the user's question directly, clearly, and concisely based strictly on the provided page evidence. "
                "Output ONLY the natural-language answer text. Do not output raw JSON, match scores, or artificial formatting."
            ),
        }

        sorted_evidence = sorted(evidence_pages, key=lambda x: x.fused_score, reverse=True)[:3]
        user_content = [{"type": "text", "text": f"Question: {question}\n\nRetrieved Evidence Pages:\n"}]

        for page in sorted_evidence:
            page_text = f"--- Document: {page.document_name}, Page: {page.page_number} ---\n{page.extracted_text}\n"
            user_content.append({"type": "text", "text": page_text})
            image_uri = self._encode_image(page.image_path)
            if image_uri:
                user_content.append({
                    "type": "image_url",
                    "image_url": {"url": image_uri},
                })

        return [system_message, {"role": "user", "content": user_content}]

    def _extractive_synthesize(self, question: str, evidence_pages: List[EvidencePage]) -> str:
        """
        Locally synthesizes clean natural-language answer from retrieved pages
        when external VLM is not running. Extracts strictly answer sentences.
        """
        if not evidence_pages:
            return "No relevant information could be found in the current search scope."

        q_terms = set(re.findall(r"\w+", question.lower())) - {
            "what", "is", "the", "a", "an", "how", "why", "where", "who", "which", "are",
            "tell", "me", "about", "describe", "explain", "in", "of", "to", "for", "with"
        }

        candidates = []
        for page in evidence_pages[:3]:
            text = page.extracted_text.strip()
            if not text:
                continue

            # Split by punctuation into sentences
            sentences = [s.strip() for s in re.split(r"[.\n]+", text) if len(s.strip()) > 20]
            for sentence in sentences:
                s_lower = sentence.lower()
                matches = sum(1 for term in q_terms if term in s_lower)
                if matches > 0:
                    candidates.append((matches, sentence))

        candidates.sort(key=lambda x: x[0], reverse=True)

        if candidates:
            # Pick top 2-3 most relevant unique sentences
            selected = []
            seen = set()
            for _, sent in candidates[:4]:
                if sent not in seen:
                    seen.add(sent)
                    selected.append(sent)

            answer = ". ".join(selected)
            if not answer.endswith("."):
                answer += "."
            return answer

        # Fallback to direct page snippet
        top_p = evidence_pages[0]
        snippet = top_p.extracted_text[:350].strip()
        if snippet:
            return f"According to {top_p.document_name} (Page {top_p.page_number}), {snippet}..."
        
        return "The document pages were retrieved based on visual structure and layout. Please inspect the visual evidence panels below."

    def generate(
        self,
        question: str,
        evidence_pages: List[EvidencePage],
        stream: bool = True,
    ) -> Union[Generator[str, None, None], str]:
        if not evidence_pages:
            msg = "No evidence pages found. Please ensure documents are uploaded and indexed."
            return (chunk for chunk in [msg]) if stream else msg

        if not self._is_available:
            ans = self._extractive_synthesize(question, evidence_pages)
            if stream:
                def _gen():
                    for word in ans.split(" "):
                        yield word + " "
                return _gen()
            return ans

        try:
            messages = self._prepare_messages(question, evidence_pages)
            if stream:
                def _stream():
                    resp = self.client.chat.completions.create(
                        model=self.model_name,
                        messages=messages,
                        stream=True,
                    )
                    for chunk in resp:
                        content = chunk.choices[0].delta.content
                        if content:
                            yield content
                return _stream()
            else:
                resp = self.client.chat.completions.create(
                    model=self.model_name,
                    messages=messages,
                    stream=False,
                )
                return resp.choices[0].message.content or ""
        except Exception as e:
            logger.warning("VLM call failed (%s). Falling back to extractive synthesis.", e)
            ans = self._extractive_synthesize(question, evidence_pages)
            if stream:
                return (w + " " for w in ans.split(" "))
            return ans

    async def async_generate(
        self,
        question: str,
        evidence_pages: List[EvidencePage],
    ) -> AsyncGenerator[str, None]:
        if not evidence_pages:
            yield "No evidence pages found. Please ensure documents are uploaded and indexed."
            return

        if not self._is_available:
            ans = self._extractive_synthesize(question, evidence_pages)
            for word in ans.split(" "):
                yield word + " "
            return

        try:
            messages = self._prepare_messages(question, evidence_pages)
            resp = await self.async_client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                stream=True,
            )
            async for chunk in resp:
                content = chunk.choices[0].delta.content
                if content:
                    yield content
        except Exception as e:
            logger.warning("Async VLM call failed (%s). Falling back to extractive synthesis.", e)
            ans = self._extractive_synthesize(question, evidence_pages)
            for word in ans.split(" "):
                yield word + " "
