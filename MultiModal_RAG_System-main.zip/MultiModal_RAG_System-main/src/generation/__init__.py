"""Generation subpackage — Vision language model interface."""
