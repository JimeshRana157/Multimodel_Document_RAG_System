"""API package — FastAPI application."""
