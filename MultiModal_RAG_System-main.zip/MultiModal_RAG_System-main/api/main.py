import logging
import sys
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn

from src.config import get_settings
from api.routes import router

# Configure structured logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting Multimodal Financial RAG API")
    settings = get_settings()
    
    # Ensure data directories exist
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    settings.index_dir.mkdir(parents=True, exist_ok=True)
    settings.page_renders_dir.mkdir(parents=True, exist_ok=True)
    settings.raw_uploads_dir.mkdir(parents=True, exist_ok=True)
    
    app.state.settings = settings
    yield
    logger.info("Shutting down Multimodal Financial RAG API")

app = FastAPI(
    title="Multimodal Financial RAG API",
    version="1.0.0",
    description="Enterprise financial document search with multimodal retrieval",
    lifespan=lifespan
)

settings = get_settings()

app.add_middleware(
    CORSMiddleware,
    allow_origins=getattr(settings, "cors_origin_list", ["*"]),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static/pages", StaticFiles(directory=str(settings.page_renders_dir)), name="static_pages")

app.include_router(router)

if __name__ == '__main__':
    uvicorn.run("api.main:app", host="0.0.0.0", port=8000, reload=True)
