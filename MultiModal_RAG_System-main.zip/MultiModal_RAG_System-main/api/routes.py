"""
Multimodal Financial RAG — REST API Routes

All endpoints with Pydantic models, validation, and structured error handling.
"""

import logging
import time
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, UploadFile, File, BackgroundTasks, HTTPException
from fastapi.responses import StreamingResponse, FileResponse
from pydantic import BaseModel
from PIL import Image

from src.config import get_settings
from src.ingestion.pdf_processor import PDFProcessor
from src.ingestion.text_extractor import TextExtractor
from src.indexing.bm25_indexer import BM25Index
from src.indexing.qdrant_store import QdrantStore
from src.retrieval.hybrid_fusion import HybridRetriever
from src.generation.vision_llm import VisionLLM, EvidencePage

logger = logging.getLogger(__name__)

router = APIRouter()
settings = get_settings()

# ---------------------------------------------------------------------------
# Lazy initialization — heavy resources are loaded once on first use
# ---------------------------------------------------------------------------
_colpali_embedder = None
_qdrant_store: Optional[QdrantStore] = None
_bm25_index: Optional[BM25Index] = None
_vision_llm: Optional[VisionLLM] = None


def _get_colpali():
    global _colpali_embedder
    if _colpali_embedder is None:
        from src.indexing.colpali_engine import ColPaliEmbedder
        logger.info("Initializing ColPaliEmbedder (first use)…")
        _colpali_embedder = ColPaliEmbedder()
    return _colpali_embedder


def _get_qdrant() -> QdrantStore:
    global _qdrant_store
    if _qdrant_store is None:
        logger.info("Initializing QdrantStore…")
        _qdrant_store = QdrantStore()
    return _qdrant_store


def _get_bm25() -> BM25Index:
    global _bm25_index
    if _bm25_index is None:
        logger.info("Initializing BM25Index…")
        _bm25_index = BM25Index()
    return _bm25_index


def _get_vlm() -> VisionLLM:
    global _vision_llm
    if _vision_llm is None:
        logger.info("Initializing VisionLLM…")
        _vision_llm = VisionLLM()
    return _vision_llm


# ---------------------------------------------------------------------------
# Pydantic Models
# ---------------------------------------------------------------------------
class DocumentResponse(BaseModel):
    document_id: str
    document_name: str
    total_pages: int
    upload_timestamp: str
    index_status: str


class SearchRequest(BaseModel):
    query: str
    top_k: int = 5
    visual_weight: float = 0.7
    lexical_weight: float = 0.3
    doc_filter: Optional[str] = None


class SearchResultItem(BaseModel):
    document_id: str
    document_name: str
    page_number: int
    visual_score: float
    lexical_score: float
    fused_score: float
    image_path: str
    extracted_text: str


class SearchResponse(BaseModel):
    query: str
    results: List[SearchResultItem]
    retrieval_time_ms: float


class AskRequest(BaseModel):
    question: str
    top_k: int = 5
    visual_weight: float = 0.7
    lexical_weight: float = 0.3


class HealthResponse(BaseModel):
    status: str
    qdrant_connected: bool
    model_loaded: bool
    vlm_available: bool
    indexed_documents: int
    indexed_pages: int


class IndexRequest(BaseModel):
    document_ids: Optional[List[str]] = None


# ---------------------------------------------------------------------------
# POST /documents/upload
# ---------------------------------------------------------------------------
@router.post("/documents/upload", response_model=List[DocumentResponse])
async def upload_documents(
    files: List[UploadFile] = File(...),
    background_tasks: BackgroundTasks = BackgroundTasks(),
):
    """Upload and process PDF files: save, render pages to PNG, extract text, and auto-index."""
    if not files:
        raise HTTPException(400, "No files uploaded")
    if len(files) > settings.max_files:
        raise HTTPException(400, f"Maximum {settings.max_files} files allowed")

    processor = PDFProcessor()
    text_extractor = TextExtractor()
    responses: list[DocumentResponse] = []
    uploaded_ids: list[str] = []

    for file in files:
        if not file.filename or not file.filename.lower().endswith(".pdf"):
            raise HTTPException(400, f"Only PDF files are accepted, got: {file.filename}")

        content = await file.read()
        if len(content) > settings.max_upload_size:
            raise HTTPException(400, f"File {file.filename} exceeds max upload size")

        # Save raw upload
        file_path = settings.raw_uploads_dir / file.filename
        file_path.write_bytes(content)

        try:
            # Process PDF → rendered page images + metadata
            doc_meta = processor.process_pdf(file_path)

            # Extract text from each page
            pages_text = text_extractor.extract_text(file_path)

            # Persist extracted text in metadata
            meta_path = settings.index_dir / f"{doc_meta.document_id}_text.json"
            import json
            text_data = [
                {"page_number": pt.page_number, "raw_text": pt.raw_text, "tables": pt.tables}
                for pt in pages_text
            ]
            meta_path.write_text(json.dumps(text_data, ensure_ascii=False), encoding="utf-8")

            responses.append(DocumentResponse(
                document_id=doc_meta.document_id,
                document_name=doc_meta.document_name,
                total_pages=doc_meta.total_pages,
                upload_timestamp=doc_meta.upload_timestamp,
                index_status="indexing",
            ))
            uploaded_ids.append(doc_meta.document_id)
        except Exception as e:
            logger.error("Failed to process %s: %s", file.filename, e)
            raise HTTPException(500, f"Error processing {file.filename}: {e}")

    # Auto-trigger indexing in background
    if uploaded_ids:
        background_tasks.add_task(_run_indexing, uploaded_ids)

    return responses


# ---------------------------------------------------------------------------
# POST /documents/index — background indexing
# ---------------------------------------------------------------------------
def _run_indexing(document_ids: List[str]):
    """Background task: embed pages with ColPali, add to BM25 + Qdrant."""
    import json
    try:
        bm25 = _get_bm25()
        qdrant = _get_qdrant()
        colpali = _get_colpali()

        # Ensure Qdrant collection exists
        try:
            qdrant.ensure_collection(colpali.embedding_dim)
        except Exception as e:
            logger.warning("Could not ensure Qdrant collection: %s", e)

        processor = PDFProcessor()

        # If no specific IDs, index all documents
        if not document_ids:
            all_docs = processor.list_documents()
            document_ids = [d.document_id for d in all_docs]

        for doc_id in document_ids:
            logger.info("Indexing document %s", doc_id)
            try:
                doc_meta = processor.load_metadata(doc_id)

                # Load extracted text
                text_path = settings.index_dir / f"{doc_id}_text.json"
                page_texts: list[dict] = []
                if text_path.exists():
                    page_texts = json.loads(text_path.read_text(encoding="utf-8"))

                # 1. Add to BM25 first (instant text retrieval)
                from src.ingestion.text_extractor import PageText
                bm25_pages = []
                for pt in page_texts:
                    bm25_pages.append(PageText(
                        page_number=pt.get("page_number", 1),
                        raw_text=pt.get("raw_text", ""),
                        tables=pt.get("tables", []),
                    ))
                if bm25_pages:
                    bm25.add_document(doc_id, bm25_pages)

                # 2. Load page images and embed
                images = []
                for img_path in doc_meta.page_image_paths:
                    p = Path(img_path) if not isinstance(img_path, Path) else img_path
                    if p.exists():
                        images.append(Image.open(p).convert("RGB"))

                if images:
                    embeddings = colpali.embed_pages(images)

                    # Prepare metadata and embeddings for Qdrant
                    page_embeddings = []
                    metadata_list = []
                    for page_idx in range(len(images)):
                        page_num = page_idx + 1
                        emb = embeddings[page_idx].tolist()  # [num_patches, embed_dim]
                        page_embeddings.append(emb)

                        ext_text = ""
                        if page_idx < len(page_texts):
                            ext_text = page_texts[page_idx].get("raw_text", "")

                        img_path_str = str(doc_meta.page_image_paths[page_idx]) if page_idx < len(doc_meta.page_image_paths) else ""

                        metadata_list.append({
                            "document_id": doc_id,
                            "document_name": doc_meta.document_name,
                            "page_number": page_num,
                            "image_path": img_path_str,
                            "extracted_text": ext_text[:2000],
                            "total_pages": doc_meta.total_pages,
                        })

                    # Upsert to Qdrant
                    qdrant.upsert_pages(page_embeddings, metadata_list)

                logger.info("Successfully indexed document %s (%d pages)", doc_id, len(images) or len(bm25_pages))

            except Exception as e:
                logger.error("Failed to index document %s: %s", doc_id, e)

    except Exception as e:
        logger.error("Indexing task failed: %s", e)


@router.post("/documents/index")
async def index_documents(
    request: IndexRequest = IndexRequest(),
    background_tasks: BackgroundTasks = BackgroundTasks(),
):
    """Start background indexing for specified (or all) documents."""
    doc_ids = request.document_ids or []

    # If no IDs specified, gather all
    if not doc_ids:
        processor = PDFProcessor()
        all_docs = processor.list_documents()
        doc_ids = [d.document_id for d in all_docs]

    if not doc_ids:
        raise HTTPException(400, "No documents to index. Upload PDFs first.")

    background_tasks.add_task(_run_indexing, doc_ids)
    return {"status": "indexing_started", "document_ids": doc_ids}


# ---------------------------------------------------------------------------
# GET /documents
# ---------------------------------------------------------------------------
@router.get("/documents", response_model=List[DocumentResponse])
async def list_documents():
    """List all processed documents with index status."""
    processor = PDFProcessor()
    docs = processor.list_documents()

    # Check which are indexed in Qdrant
    indexed_doc_ids = set()
    try:
        qdrant = _get_qdrant()
        indexed_docs = qdrant.get_all_documents()
        indexed_doc_ids = {d["document_id"] for d in indexed_docs}
    except Exception:
        pass  # Qdrant might not be available yet

    return [
        DocumentResponse(
            document_id=doc.document_id,
            document_name=doc.document_name,
            total_pages=doc.total_pages,
            upload_timestamp=doc.upload_timestamp,
            index_status="indexed" if doc.document_id in indexed_doc_ids else "uploaded",
        )
        for doc in docs
    ]


# ---------------------------------------------------------------------------
# DELETE /documents/{document_id}
# ---------------------------------------------------------------------------
@router.delete("/documents/{document_id}")
async def delete_document(document_id: str):
    """Remove a document from all indices and storage."""
    try:
        # Remove from Qdrant
        try:
            qdrant = _get_qdrant()
            qdrant.delete_document(document_id)
        except Exception as e:
            logger.warning("Qdrant delete failed: %s", e)

        # Remove from BM25
        try:
            bm25 = _get_bm25()
            bm25.remove_document(document_id)
        except Exception as e:
            logger.warning("BM25 delete failed: %s", e)

        # Remove files
        processor = PDFProcessor()
        processor.delete_document(document_id)

        return {"status": "deleted", "document_id": document_id}
    except Exception as e:
        raise HTTPException(500, str(e))


# ---------------------------------------------------------------------------
# POST /search
# ---------------------------------------------------------------------------
@router.post("/search", response_model=SearchResponse)
async def search(request: SearchRequest):
    """Run hybrid retrieval search."""
    if not request.query.strip():
        raise HTTPException(400, "Query cannot be empty")

    start_time = time.time()
    bm25 = _get_bm25()
    qdrant = _get_qdrant()
    retriever = HybridRetriever(bm25, qdrant)

    # Try to get visual embeddings
    query_embedding = None
    try:
        colpali = _get_colpali()
        query_emb_tensor = colpali.embed_query(request.query)
        query_embedding = query_emb_tensor.squeeze(0).tolist()
    except Exception as e:
        logger.warning("ColPali query embedding failed, using BM25 only: %s", e)

    fused = retriever.retrieve(
        query=request.query,
        query_embedding=query_embedding,
        top_k=request.top_k,
        visual_weight=request.visual_weight,
        lexical_weight=request.lexical_weight,
        doc_filter=request.doc_filter,
    )

    retrieval_time = (time.time() - start_time) * 1000

    results = [
        SearchResultItem(
            document_id=r.document_id,
            document_name=r.document_name,
            page_number=r.page_number,
            visual_score=r.visual_score,
            lexical_score=r.lexical_score,
            fused_score=r.fused_score,
            image_path=r.image_path,
            extracted_text=r.extracted_text,
        )
        for r in fused
    ]

    return SearchResponse(
        query=request.query,
        results=results,
        retrieval_time_ms=round(retrieval_time, 2),
    )


# ---------------------------------------------------------------------------
# POST /ask — streaming VLM answer
# ---------------------------------------------------------------------------
@router.post("/ask")
async def ask(request: AskRequest):
    """Answer a question with streaming VLM generation grounded in retrieved evidence."""
    if not request.question.strip():
        raise HTTPException(400, "Question cannot be empty")

    # First retrieve evidence
    bm25 = _get_bm25()
    qdrant = _get_qdrant()
    retriever = HybridRetriever(bm25, qdrant)

    query_embedding = None
    try:
        colpali = _get_colpali()
        query_emb = colpali.embed_query(request.question)
        query_embedding = query_emb.squeeze(0).tolist()
    except Exception as e:
        logger.warning("ColPali unavailable for /ask: %s", e)

    fused = retriever.retrieve(
        query=request.question,
        query_embedding=query_embedding,
        top_k=request.top_k,
        visual_weight=request.visual_weight,
        lexical_weight=request.lexical_weight,
    )

    # Convert to EvidencePage for VLM
    evidence_pages = [
        EvidencePage(
            document_name=r.document_name,
            page_number=r.page_number,
            image_path=r.image_path,
            extracted_text=r.extracted_text,
            fused_score=r.fused_score,
        )
        for r in fused
    ]

    vlm = _get_vlm()

    async def event_stream():
        try:
            async for chunk in vlm.async_generate(request.question, evidence_pages):
                yield f"data: {chunk}\n\n"
            yield "data: [DONE]\n\n"
        except Exception as e:
            logger.error("Streaming error: %s", e)
            yield f"data: Error: {e}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


# ---------------------------------------------------------------------------
# GET /health
# ---------------------------------------------------------------------------
@router.get("/health", response_model=HealthResponse)
async def health():
    """System health check."""
    qdrant_ok = False
    indexed_docs = 0
    indexed_pages = 0

    try:
        qdrant = _get_qdrant()
        qdrant_ok = qdrant.health_check()
        if qdrant_ok:
            indexed_pages = qdrant.count_points()
            all_docs = qdrant.get_all_documents()
            indexed_docs = len(all_docs)
    except Exception:
        pass

    vlm_ok = False
    try:
        vlm = _get_vlm()
        vlm_ok = vlm._is_available
    except Exception:
        pass

    return HealthResponse(
        status="healthy" if qdrant_ok else "degraded",
        qdrant_connected=qdrant_ok,
        model_loaded=_colpali_embedder is not None,
        vlm_available=vlm_ok,
        indexed_documents=indexed_docs,
        indexed_pages=indexed_pages,
    )


# ---------------------------------------------------------------------------
# GET /pages/{document_id}/{page_number}
# ---------------------------------------------------------------------------
@router.get("/pages/{document_id}/{page_number}")
async def get_page_image(document_id: str, page_number: int):
    """Serve a rendered page image."""
    page_path = settings.page_renders_dir / document_id / f"page_{page_number:04d}.png"
    if not page_path.exists():
        # Try without zero-padding
        page_path = settings.page_renders_dir / document_id / f"page_{page_number}.png"
    if not page_path.exists():
        raise HTTPException(404, f"Page {page_number} not found for document {document_id}")
    return FileResponse(str(page_path), media_type="image/png")
