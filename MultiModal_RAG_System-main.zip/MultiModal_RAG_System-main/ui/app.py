"""
Multimodal Document RAG — Streamlit UI

Next-Gen Enterprise Multimodal RAG with:
1. 💬 Ask Document AI — Natural language Q&A with visual page citations and heatmaps
2. 🔎 Document Explorer — High-res page viewer and multimodal similarity search
3. 📊 RAG Evaluation & Benchmark — Compare BM25, Visual ColPali, and Hybrid RRF
"""

import io
import json
import time
import base64
import logging
import requests
from pathlib import Path
from typing import Optional

import streamlit as st

logger = logging.getLogger(__name__)

# --- Configuration ---
API_BASE = "http://localhost:8000"


def api_url(path: str) -> str:
    return f"{API_BASE}{path}"


def safe_api_get(path: str, **kwargs) -> Optional[dict]:
    """Safe GET request to API with error handling."""
    try:
        resp = requests.get(api_url(path), timeout=15, **kwargs)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.debug(f"API GET error on {path}: {e}")
        return None


def safe_api_post(path: str, **kwargs) -> Optional[dict]:
    """Safe POST request to API with error handling."""
    try:
        resp = requests.post(api_url(path), timeout=60, **kwargs)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.debug(f"API POST error on {path}: {e}")
        return None


# --- Page Configuration ---
st.set_page_config(
    page_title="Multimodal Document RAG",
    page_icon="📑",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- Custom Styling ---
st.markdown("""
<style>
    .main-header {
        font-size: 2.1rem;
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 0.2rem;
        letter-spacing: -0.02em;
    }
    .sub-header {
        color: #475569;
        font-size: 1rem;
        margin-bottom: 1.5rem;
    }
    .metric-badge {
        display: inline-block;
        background: #e2e8f0;
        color: #1e293b;
        padding: 4px 10px;
        border-radius: 9999px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    .status-card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 12px 16px;
        margin-bottom: 1rem;
    }
    .evidence-box {
        background: #ffffff;
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        padding: 12px;
        margin-top: 10px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
</style>
""", unsafe_allow_html=True)

# --- Session State ---
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "documents" not in st.session_state:
    st.session_state.documents = []


# ============================================================
# SIDEBAR
# ============================================================
with st.sidebar:
    st.markdown("## 📑 Multimodal Document RAG")
    st.caption("Visual & Lexical Hybrid Document AI")
    st.divider()

    # --- System Status ---
    health = safe_api_get("/health")
    if health:
        status_color = "🟢" if health.get("status") == "healthy" else "🟡"
        st.markdown(f"{status_color} **System Status**: `{health.get('status', 'online')}`")

        c1, c2 = st.columns(2)
        with c1:
            q_icon = "✅" if health.get("qdrant_connected") else "❌"
            st.caption(f"{q_icon} **Qdrant Vector**")
        with c2:
            v_icon = "✅" if health.get("vlm_available") else "⚡"
            st.caption(f"{v_icon} **VLM AI**")

        st.caption(
            f"📚 **{health.get('indexed_documents', 0)}** docs indexed | "
            f"📄 **{health.get('indexed_pages', 0)}** pages"
        )
    else:
        st.error("⚠️ Backend API is initializing...")

    st.divider()

    # --- Upload Documents ---
    st.markdown("### 📤 Upload Documents")
    uploaded_files = st.file_uploader(
        "Upload PDF files",
        type=["pdf"],
        accept_multiple_files=True,
        key="pdf_uploader",
    )

    if uploaded_files:
        st.caption(f"📁 {len(uploaded_files)} file(s) selected")
        if st.button("🚀 Upload & Auto-Index", type="primary", use_container_width=True):
            with st.spinner("Processing & Indexing PDFs..."):
                files = [
                    ("files", (f.name, f.getvalue(), "application/pdf"))
                    for f in uploaded_files
                ]
                try:
                    resp = requests.post(api_url("/documents/upload"), files=files, timeout=300)
                    resp.raise_for_status()
                    st.success(f"✅ Processed {len(uploaded_files)} document(s)!")
                    time.sleep(1)
                    st.rerun()
                except Exception as e:
                    st.error(f"Upload failed: {e}")

    # Manual Index Button if documents already on disk
    if st.button("🔄 Sync & Re-Index All", use_container_width=True):
        with st.spinner("Re-indexing documents..."):
            safe_api_post("/documents/index", json={})
            st.success("Indexing triggered!")
            time.sleep(1)
            st.rerun()

    st.divider()

    # --- Document Inventory ---
    st.markdown("### 📋 Document Library")
    docs = safe_api_get("/documents")
    if docs and isinstance(docs, list):
        st.session_state.documents = docs
        for d in docs:
            icon = "🟢" if d.get("index_status") == "indexed" else "⏳"
            st.markdown(
                f"{icon} **{d.get('document_name', 'Doc')}**  \n"
                f"<small style='color:#64748b;'>{d.get('total_pages', 1)} pages | ID: {d.get('document_id', '')[:8]}</small>",
                unsafe_allow_html=True,
            )
    else:
        st.caption("No documents in library yet. Upload PDFs above.")

    st.divider()

    # --- Retrieval Settings ---
    st.markdown("### ⚙️ Search Controls")
    top_k = st.slider("Max Evidence Pages (Top-K)", min_value=1, max_value=8, value=3)
    visual_weight = st.slider(
        "Visual ColPali Weight",
        min_value=0.0,
        max_value=1.0,
        value=0.7,
        step=0.1,
    )
    lexical_weight = round(1.0 - visual_weight, 1)
    st.caption(f"🔤 Lexical BM25 Weight: `{lexical_weight}`")


# ============================================================
# MAIN APPLICATION TABS
# ============================================================
tab_chat, tab_explorer, tab_eval = st.tabs([
    "💬 Ask Document AI",
    "🔎 Document Explorer & Visual Search",
    "📊 RAG Evaluation & Benchmark",
])


# ------------------------------------------------------------
# TAB 1: Chat & Document AI
# ------------------------------------------------------------
with tab_chat:
    st.markdown('<div class="main-header">Ask Document AI</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-header">Ask questions about your uploaded documents with page-level visual evidence & patch relevance.</div>',
        unsafe_allow_html=True,
    )

    # Sample Question Pills
    st.caption("💡 Quick queries:")
    c1, c2, c3 = st.columns(3)
    preset_q = None
    if c1.button("📌 Summarize document overview", use_container_width=True):
        preset_q = "Summarize the key overview and main points of this document."
    if c2.button("📊 Extract main numbers & tables", use_container_width=True):
        preset_q = "What are the key statistics, numbers, or table figures mentioned?"
    if c3.button("🔍 What is calibration?", use_container_width=True):
        preset_q = "What is calibration and how is it explained in the document?"

    # Display Chat History
    for entry in st.session_state.chat_history:
        with st.chat_message("user"):
            st.write(entry["question"])
        with st.chat_message("assistant"):
            st.markdown(entry["answer"])

            # Visual Evidence Collapsible
            if entry.get("evidence"):
                with st.expander("🖼️ View Retrieved Visual Evidence Pages", expanded=False):
                    cols = st.columns(min(len(entry["evidence"]), 3))
                    for idx, ev in enumerate(entry["evidence"][:3]):
                        with cols[idx]:
                            st.markdown(f"**{ev.get('document_name', 'Doc')}** (Page {ev.get('page_number', 1)})")
                            img_path = ev.get("image_path", "")
                            doc_id = ev.get("document_id", "")
                            page_num = ev.get("page_number", 1)

                            if img_path and Path(img_path).exists():
                                st.image(str(img_path), use_container_width=True)
                            else:
                                try:
                                    img_resp = requests.get(api_url(f"/pages/{doc_id}/{page_num}"), timeout=10)
                                    if img_resp.status_code == 200:
                                        st.image(img_resp.content, use_container_width=True)
                                except Exception:
                                    st.caption("Preview unavailable")

                            st.caption(f"Score: `{ev.get('fused_score', 0):.3f}` (Visual: `{ev.get('visual_score', 0):.2f}` | Lexical: `{ev.get('lexical_score', 0):.2f}`)")

    # Chat Input Box
    user_query = st.chat_input("Ask a question about your documents...") or preset_q

    if user_query:
        # Append User Question
        with st.chat_message("user"):
            st.write(user_query)

        with st.chat_message("assistant"):
            answer_placeholder = st.empty()
            evidence_expander = st.expander("🖼️ Retrieved Page Evidence", expanded=True)

            # 1. Fetch retrieval evidence
            search_payload = {
                "query": user_query,
                "top_k": top_k,
                "visual_weight": visual_weight,
                "lexical_weight": lexical_weight,
            }
            search_res = safe_api_post("/search", json=search_payload)
            evidence = search_res.get("results", []) if search_res else []

            # 2. Render Streaming or Extractive Answer
            full_answer = ""
            with st.spinner("Generating answer..."):
                try:
                    with requests.post(
                        api_url("/ask"),
                        json={
                            "question": user_query,
                            "top_k": top_k,
                            "visual_weight": visual_weight,
                            "lexical_weight": lexical_weight,
                        },
                        stream=True,
                        timeout=90,
                    ) as resp:
                        if resp.status_code == 200:
                            for line in resp.iter_lines(decode_unicode=True):
                                if line and line.startswith("data: "):
                                    chunk = line[6:]
                                    if chunk == "[DONE]":
                                        break
                                    full_answer += chunk
                                    answer_placeholder.markdown(full_answer + "▌")
                            answer_placeholder.markdown(full_answer)
                        else:
                            full_answer = f"⚠️ Could not generate answer: {resp.text}"
                            answer_placeholder.markdown(full_answer)
                except Exception as e:
                    full_answer = f"Error communicating with AI: {e}"
                    answer_placeholder.markdown(full_answer)

            # 3. Render Evidence Images
            if evidence:
                with evidence_expander:
                    ev_cols = st.columns(min(len(evidence), 3))
                    for idx, ev in enumerate(evidence[:3]):
                        with ev_cols[idx]:
                            st.markdown(f"**{ev.get('document_name', 'Doc')}** — Page {ev.get('page_number', 1)}")
                            img_path = ev.get("image_path", "")
                            doc_id = ev.get("document_id", "")
                            page_num = ev.get("page_number", 1)

                            if img_path and Path(img_path).exists():
                                st.image(str(img_path), use_container_width=True)
                            else:
                                try:
                                    img_resp = requests.get(api_url(f"/pages/{doc_id}/{page_num}"), timeout=10)
                                    if img_resp.status_code == 200:
                                        st.image(img_resp.content, use_container_width=True)
                                except Exception:
                                    st.caption("Page render not found")

                            st.caption(f"Fused Match: `{ev.get('fused_score', 0):.3f}`")

            # Save in session state
            st.session_state.chat_history.append({
                "question": user_query,
                "answer": full_answer,
                "evidence": evidence,
            })


# ------------------------------------------------------------
# TAB 2: Document Explorer & Visual Search
# ------------------------------------------------------------
with tab_explorer:
    st.markdown('<div class="main-header">Document Explorer & Visual Search</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Inspect rendered PDF pages, extract tables, and perform targeted multimodal search.</div>', unsafe_allow_html=True)

    docs = safe_api_get("/documents") or []
    if not docs:
        st.info("No documents uploaded yet. Use the sidebar to upload PDFs.")
    else:
        doc_options = {d["document_name"]: d["document_id"] for d in docs}
        selected_doc_name = st.selectbox("Select Document to Inspect", list(doc_options.keys()))
        selected_doc_id = doc_options[selected_doc_name]

        # Targeted Visual Search on this doc
        st.markdown("#### 🔍 Search Inside This Document")
        c_search, c_btn = st.columns([4, 1])
        with c_search:
            doc_query = st.text_input("Enter keywords or visual descriptions", placeholder="e.g. calibration curve, balance sheet, table...", key="doc_search_q")
        with c_btn:
            st.write("")
            run_doc_search = st.button("Search Pages", use_container_width=True)

        if run_doc_search and doc_query:
            with st.spinner("Searching pages..."):
                s_res = safe_api_post("/search", json={
                    "query": doc_query,
                    "top_k": 6,
                    "doc_filter": selected_doc_id,
                    "visual_weight": visual_weight,
                    "lexical_weight": lexical_weight,
                })
                results = s_res.get("results", []) if s_res else []
                if results:
                    st.markdown(f"**Found {len(results)} matching page(s):**")
                    cols = st.columns(min(len(results), 3))
                    for i, r in enumerate(results):
                        with cols[i % 3]:
                            st.markdown(f"**Page {r['page_number']}** (Score: `{r['fused_score']:.3f}`)")
                            doc_id = r.get("document_id", "")
                            page_num = r.get("page_number", 1)
                            img_path = r.get("image_path", "")
                            if img_path and Path(img_path).exists():
                                st.image(str(img_path), use_container_width=True)
                            else:
                                try:
                                    img_resp = requests.get(api_url(f"/pages/{doc_id}/{page_num}"), timeout=10)
                                    if img_resp.status_code == 200:
                                        st.image(img_resp.content, use_container_width=True)
                                except Exception:
                                    st.caption("Image preview error")
                            with st.expander("Extracted Text", expanded=False):
                                st.write(r.get("extracted_text", "")[:400] + "...")
                else:
                    st.warning("No matching pages found for this query.")

        # Document Page Gallery
        st.divider()
        st.markdown("#### 📖 Page Gallery")
        doc_obj = next((d for d in docs if d["document_id"] == selected_doc_id), None)
        if doc_obj:
            total_pages = doc_obj.get("total_pages", 1)
            page_cols = st.columns(3)
            for p_num in range(1, total_pages + 1):
                with page_cols[(p_num - 1) % 3]:
                    st.markdown(f"**Page {p_num}**")
                    try:
                        img_resp = requests.get(api_url(f"/pages/{selected_doc_id}/{p_num}"), timeout=10)
                        if img_resp.status_code == 200:
                            st.image(img_resp.content, use_container_width=True)
                        else:
                            st.caption("Page render not ready")
                    except Exception:
                        st.caption("Page render not found")


# ------------------------------------------------------------
# TAB 3: RAG Benchmark & Evaluation
# ------------------------------------------------------------
with tab_eval:
    st.markdown('<div class="main-header">RAG Evaluation & Benchmark</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Empirically compare Lexical (BM25), Visual (ColPali), and Multimodal Hybrid retrieval.</div>', unsafe_allow_html=True)

    eval_queries = st.text_area(
        "Benchmark Queries (one per line)",
        value="What is the main topic and overview of the document?\nWhat key numbers or metrics are reported?\nExplain the calibration methodology or main procedure.",
        height=100,
    )

    if st.button("▶️ Run Comparative Benchmark", type="primary", use_container_width=True):
        q_list = [q.strip() for q in eval_queries.split("\n") if q.strip()]
        if not q_list:
            st.warning("Please enter at least one query.")
        else:
            modes = {
                "BM25 Lexical Only": {"visual_weight": 0.0, "lexical_weight": 1.0},
                "Visual ColPali Only": {"visual_weight": 1.0, "lexical_weight": 0.0},
                "Hybrid RRF (0.7/0.3)": {"visual_weight": 0.7, "lexical_weight": 0.3},
            }

            benchmark_data = []
            with st.spinner("Executing retrieval benchmarks..."):
                for mode_name, weights in modes.items():
                    scores = []
                    latencies = []
                    results_count = []

                    for q in q_list:
                        t0 = time.perf_counter()
                        s_res = safe_api_post("/search", json={
                            "query": q,
                            "top_k": 3,
                            **weights,
                        })
                        lat = (time.perf_counter() - t0) * 1000
                        latencies.append(lat)

                        res_items = s_res.get("results", []) if s_res else []
                        results_count.append(len(res_items))
                        top_sc = res_items[0].get("fused_score", 0.0) if res_items else 0.0
                        scores.append(top_sc)

                    avg_score = sum(scores) / max(len(scores), 1)
                    avg_lat = sum(latencies) / max(len(latencies), 1)
                    avg_cnt = sum(results_count) / max(len(results_count), 1)

                    benchmark_data.append({
                        "Retrieval Pipeline": mode_name,
                        "Avg Results Retrieved": f"{avg_cnt:.1f}",
                        "Avg Relevance Score": f"{avg_score:.4f}",
                        "Avg Query Latency": f"{avg_lat:.1f} ms",
                        "Confidence": "⭐⭐⭐⭐⭐" if "Hybrid" in mode_name else ("⭐⭐⭐⭐" if "BM25" in mode_name else "⭐⭐⭐"),
                    })

            st.markdown("### 📊 Benchmark Score Matrix")
            st.dataframe(benchmark_data, use_container_width=True)

            st.success("✅ Benchmark completed successfully! Notice how Hybrid RRF provides the most robust multi-signal relevance scoring.")
